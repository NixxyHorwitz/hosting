<?php
require_once __DIR__ . '/../../config/database.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }

require_once __DIR__ . '/../../library/session.php';

$user_id = $_SESSION['user_id'];

// Get user orders for the "Produk/Layanan" dropdown
$orders_query = mysqli_query($conn, "SELECT o.id, o.domain, hp.nama_paket 
                                     FROM orders o 
                                     JOIN hosting_plans hp ON o.hosting_plan_id = hp.id 
                                     WHERE o.user_id = '$user_id'");

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_ticket'])) {
    $dept = mysqli_real_escape_string($conn, $_POST['department']);
    $priority = mysqli_real_escape_string($conn, $_POST['priority']);
    
    $service_id = !empty($_POST['service_id']) ? "'" . mysqli_real_escape_string($conn, $_POST['service_id']) . "'" : "NULL";
    
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    // Since we're using Quill, the message comes from a hidden input
    $message = mysqli_real_escape_string($conn, $_POST['message']); 
    
    if (empty(trim(strip_tags($message)))) {
         $error = "Pesan tiket tidak boleh kosong!";
    } else {
        // Generate Ticket Number
        $ticket_num = "#" . strtoupper(substr($dept, 0, 3)) . "-" . rand(100000, 999999);
        
        // Insert ticket
        mysqli_query($conn, "INSERT INTO tickets (ticket_number, user_id, department, priority, service_id, title, status) 
                             VALUES ('$ticket_num', '$user_id', '$dept', '$priority', $service_id, '$title', 'Open')");
        $ticket_id = mysqli_insert_id($conn);
        
        // Insert message reply
        mysqli_query($conn, "INSERT INTO ticket_replies (ticket_id, user_id, message) VALUES ('$ticket_id', '$user_id', '$message')");
        $reply_id = mysqli_insert_id($conn);
        
        // Handle attachments
        if (!empty($_FILES['attachments']['name'][0])) {
            $upload_dir = '../uploads/tickets/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
            
            $allowed_exts = ['jpg','jpeg','png','pdf','zip','rar','txt'];
            foreach ($_FILES['attachments']['name'] as $key => $name) {
                if ($_FILES['attachments']['error'][$key] === UPLOAD_ERR_OK) {
                    $tmp_name = $_FILES['attachments']['tmp_name'][$key];
                    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
                    $size = $_FILES['attachments']['size'][$key];
                    
                    if (in_array($ext, $allowed_exts) && $size <= 5242880) { // Max 5MB
                        $new_name = uniqid('t_') . '_' . time() . '.' . $ext;
                        if (move_uploaded_file($tmp_name, $upload_dir . $new_name)) {
                            $secure_name = mysqli_real_escape_string($conn, $name);
                            $secure_path = mysqli_real_escape_string($conn, 'uploads/tickets/' . $new_name);
                            mysqli_query($conn, "INSERT INTO ticket_attachments (ticket_id, reply_id, file_name, file_path, file_size) VALUES ('$ticket_id', '$reply_id', '$secure_name', '$secure_path', '$size')");
                        }
                    }
                }
            }
        }
        
        header("Location: " . base_url("hosting/tickets/detail/$ticket_id"));
        exit();
    }
}

$page_title = "Kirim Tiket";
include __DIR__ . '/../../library/header.php';
?>

<!-- Quill Rich Text Editor CSS -->
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<style>
    /* Styling to make Quill look matching with Bootstrap 5 */
    .ql-toolbar {
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
        background: #f8f9fa;
        border-color: #dee2e6 !important;
    }
    .ql-container {
        border-bottom-left-radius: 8px;
        border-bottom-right-radius: 8px;
        border-color: #dee2e6 !important;
        font-family: inherit;
        font-size: 14px;
        background: #ffffff;
    }
    .ql-editor {
        min-height: 200px;
    }
    .form-label {
        font-size: 12.5px;
        font-weight: 700;
        color: #6c757d;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .form-control, .form-select {
        border-color: #dee2e6;
        padding: 0.6rem 1rem;
        font-size: 14px;
        border-radius: 8px;
        box-shadow: none !important;
        transition: border-color 0.2s;
    }
    .form-control:focus, .form-select:focus {
        border-color: #007bff;
    }
</style>

<div class="d-flex align-items-center mb-4 text-muted" style="font-size: 14px; font-weight: 500;">
    Dashboard <i class="bi bi-chevron-right mx-2" style="font-size: 10px;"></i> Trouble Ticket <i class="bi bi-chevron-right mx-2" style="font-size: 10px;"></i> <span class="bg-primary-subtle text-primary px-2 py-1 rounded">Buat Tiket</span>
</div>

<?php if(isset($error)): ?>
<div class="alert alert-danger fw-medium d-flex align-items-center shadow-sm" style="border-radius: 8px;">
    <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
</div>
<?php endif; ?>

<div class="card border-0 shadow-sm" style="border-radius: 12px;">
    <div class="card-header bg-white p-4 border-bottom d-flex justify-content-between align-items-center" style="border-radius: 12px 12px 0 0;">
        <h5 class="fw-bold m-0 d-flex align-items-center text-dark" style="font-size: 16px;">
            <i class="bi bi-send-fill text-primary me-2"></i> Kirim Tiket
        </h5>
        <a href="<?= base_url('hosting/tickets') ?>" class="btn text-white btn-sm px-3 fw-medium shadow-sm" style="background-color: #477aee; border-radius: 4px;">
            <i class="bi bi-chevron-left me-1"></i> Kembali
        </a>
    </div>
    <div class="card-body p-4 bg-white" style="border-radius: 0 0 12px 12px;">
        <form action="" method="POST" id="ticketForm" enctype="multipart/form-data">
            <div class="mb-4">
                <label class="form-label">Departemen</label>
                <select name="department" class="form-select" required>
                    <option value="" disabled selected>-- Silakan pilih departemen --</option>
                    <option value="Technical Support">Technical Support</option>
                    <option value="Billing">Billing</option>
                    <option value="Sales">Sales</option>
                </select>
            </div>
            
            <div class="mb-4">
                <label class="form-label">Prioritas</label>
                <select name="priority" class="form-select" required>
                    <option value="" disabled selected>-- Silakan pilih prioritas --</option>
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                </select>
            </div>
            
            <div class="mb-4">
                <label class="form-label">Produk/Layanan</label>
                <select name="service_id" class="form-select">
                    <option value="">Layanan Anda (opsional)</option>
                    <?php if(mysqli_num_rows($orders_query) > 0): ?>
                        <?php while($ord = mysqli_fetch_assoc($orders_query)): ?>
                            <option value="<?= $ord['id'] ?>"><?= htmlspecialchars($ord['nama_paket'] . ' - ' . $ord['domain']) ?></option>
                        <?php endwhile; ?>
                    <?php endif; ?>
                </select>
            </div>
            
            <div class="mb-4">
                <label class="form-label">Judul</label>
                <input type="text" name="title" class="form-control" placeholder="Masukkan judul tiket" required>
            </div>
            
            <div class="mb-4">
                <label class="form-label">Pesan</label>
                <input type="hidden" name="message" id="messageInput">
                <div id="editor"></div>
            </div>
            
            <div class="mt-4 pt-3 border-top d-flex justify-content-between align-items-center">
                <div>
                    <input type="file" name="attachments[]" id="attachments" multiple class="d-none" accept=".jpg,.jpeg,.png,.pdf,.zip,.rar,.txt">
                    <button type="button" onclick="document.getElementById('attachments').click()" class="btn text-white px-4 fw-medium shadow-sm" style="background-color: #477aee; border-radius: 4px; font-size: 14px;">
                        <i class="bi bi-paperclip me-1"></i> Tambah Lampiran
                    </button>
                    <div id="fileList" class="mt-2 text-muted" style="font-size: 11px;">Maks 5MB per file (JPG, PNG, PDF, ZIP, RAR, TXT)</div>
                </div>
                <button type="submit" name="create_ticket" class="btn text-white px-4 fw-bold shadow-sm" style="background-color: #20c997; border-radius: 4px; font-size: 14px;">
                    <i class="bi bi-send-fill me-2"></i> Kirim Tiket
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('attachments').addEventListener('change', function(e) {
    let files = e.target.files;
    let fileList = document.getElementById('fileList');
    if(files.length > 0) {
        fileList.innerHTML = '<span class="text-success"><i class="bi bi-check-circle-fill me-1"></i> ' + files.length + ' file terpilih</span>';
    } else {
        fileList.innerHTML = 'Maks 5MB per file (JPG, PNG, PDF, ZIP, RAR, TXT)';
    }
});
</script>

<!-- Quill Library -->
<script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>
<script>
    // Inisialisasi editor Quill dengan toolbar modern minimalis
    var quill = new Quill('#editor', {
        theme: 'snow',
        placeholder: 'Tulis pesan Anda di sini...',
        modules: {
            toolbar: [
                [{ 'header': [1, 2, 3, false] }],
                ['bold', 'italic', 'underline', 'strike'],
                [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                ['link', 'blockquote', 'code-block'],
                ['clean']
            ]
        }
    });

    // Masukkan data rich text HTML dari Quill ke hidden input sebelum form di submit
    var form = document.getElementById('ticketForm');
    form.onsubmit = function() {
        var messageInput = document.querySelector('input[name=message]');
        // Quill's root contains the exact html
        messageInput.value = quill.root.innerHTML;
        return true;
    };
</script>

<?php include __DIR__ . '/../../library/footer.php'; ?>
