<?php
require_once __DIR__ . '/../../config/database.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }

require_once __DIR__ . '/../../library/session.php';

$user_id = $_SESSION['user_id'];

// Fetch all tickets for user
$tickets_query = mysqli_query($conn, "SELECT t.*, 
                                     (SELECT created_at FROM ticket_replies tr WHERE tr.ticket_id = t.id ORDER BY id DESC LIMIT 1) as last_reply_time,
                                     (SELECT message FROM ticket_replies tr WHERE tr.ticket_id = t.id ORDER BY id DESC LIMIT 1) as last_reply_text,
                                     (SELECT admin_id FROM ticket_replies tr WHERE tr.ticket_id = t.id ORDER BY id DESC LIMIT 1) as last_admin_id 
                                     FROM tickets t WHERE user_id = '$user_id' ORDER BY id DESC");

$page_title = "Trouble Ticket";
include __DIR__ . '/../../library/header.php';
?>

<div class="card border-0 p-4 mb-4 shadow-sm" style="border-radius: 4px;">
    <div class="d-flex align-items-center mb-4 border-bottom pb-3">
        <div class="bg-primary-subtle text-primary rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 32px; height: 32px;">
            <i class="bi bi-headset"></i>
        </div>
        <h5 class="fw-bold m-0 text-dark" style="font-size: 16px;">Daftar Tiket</h5>
    </div>
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div class="input-group" style="max-width: 400px;">
            <input type="text" class="form-control text-muted" placeholder="Nomor tiket e.g: ABC-123456" style="border-color: #dee2e6; font-size: 13.5px; border-radius: 4px 0 0 4px !important; box-shadow: none;">
            <button class="btn bg-white fw-medium text-primary" style="border: 1px solid #dee2e6; border-left: none; border-radius: 0 4px 4px 0 !important; font-size: 13.5px;" type="button">Cari</button>
        </div>
        <a href="<?= base_url('hosting/tickets/create') ?>" class="btn text-white px-4 fw-medium shadow-sm" style="background-color: #20c997; border-radius: 4px; font-size: 14px;">
            <i class="bi bi-ticket-detailed"></i> Buat Tiket Baru
        </a>
    </div>
    <div class="table-responsive">
        <table class="table align-middle" style="border-top: 1px solid #dee2e6;">
            <thead>
                <tr>
                    <th class="py-3 text-muted" style="font-size: 11px; text-transform: uppercase;">No Tiket</th>
                    <th class="py-3 text-muted" style="font-size: 11px; text-transform: uppercase;">Departemen</th>
                    <th class="py-3 text-muted" style="font-size: 11px; text-transform: uppercase;">Judul</th>
                    <th class="py-3 text-muted" style="font-size: 11px; text-transform: uppercase;">Status</th>
                    <th class="py-3 text-muted" style="font-size: 11px; text-transform: uppercase;">Dibuat</th>
                    <th class="py-3 text-muted" style="font-size: 11px; text-transform: uppercase;">Terakhir Balas</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($tickets_query) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($tickets_query)): ?>
                    <tr style="cursor: pointer;" onclick="window.location='<?= base_url('hosting/tickets/detail/' . $row['id']) ?>';">
                        <td class="text-muted fw-medium" style="font-size: 13px;"><?= $row['ticket_number'] ?></td>
                        <td class="text-dark" style="font-size: 13px;"><?= htmlspecialchars($row['department']) ?></td>
                        <td>
                            <div class="fw-bold text-dark" style="font-size: 13.5px;"><?= htmlspecialchars($row['title']) ?></div>
                            <div class="mt-1 text-truncate" style="font-size: 12px; max-width: 320px; letter-spacing: 0.2px;">
                                <?php if($row['last_admin_id']): ?>
                                    <span style="color: #477aee; font-weight: 600;"><i class="bi bi-headset"></i> Support:</span> <span class="text-muted"><?= htmlspecialchars(substr(strip_tags($row['last_reply_text']), 0, 60)) ?>...</span>
                                <?php else: ?>
                                    <span class="text-muted"><i class="bi bi-person-fill"></i> Anda: <?= htmlspecialchars(substr(strip_tags($row['last_reply_text']), 0, 60)) ?>...</span>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <?php 
                            if($row['status'] == 'Open') echo '<span class="badge" style="background-color: #20c997; border-radius: 12px; padding: 4px 12px; font-weight: 600;">Open</span>';
                            elseif($row['status'] == 'Customer-Reply') echo '<span class="badge" style="background-color: #f39c12; border-radius: 12px; padding: 4px 12px; font-weight: 600;">Customer-Reply</span>';
                            elseif($row['status'] == 'Answered') echo '<span class="badge" style="background-color: #477aee; border-radius: 12px; padding: 4px 12px; font-weight: 600;">Answered</span>';
                            else echo '<span class="badge" style="background-color: #4b4b4b; border-radius: 12px; padding: 4px 12px; font-weight: 600;">Closed</span>';
                            ?>
                        </td>
                        <td class="text-muted" style="font-size: 13px;"><?= date('d F Y \p\u\k\u\l H.i \W\I\B', strtotime($row['created_at'])) ?></td>
                        <td class="text-muted" style="font-size: 13px;"><?= $row['last_reply_time'] ? date('d F Y \p\u\k\u\l H.i \W\I\B', strtotime($row['last_reply_time'])) : '-' ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center py-5 text-muted">Belum ada tiket support yang dibuat.<br><small>Punya masalah? Silakan buat tiket baru.</small></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="row g-4">
    <div class="col-md-6">
        <div class="card border-0 p-4 shadow-sm h-100" style="border-radius: 4px;">
            <div class="d-flex align-items-center mb-3">
                <i class="bi bi-telephone-fill text-primary me-2 fs-5"></i>
                <h6 class="fw-bold m-0 text-dark">Telepon</h6>
            </div>
            <div class="p-3 bg-white text-muted fw-medium" style="border: 1px solid #eaedf1; border-radius: 4px; font-size: 13px;"><?= CONTACT_PHONE ?></div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-0 p-4 shadow-sm h-100" style="border-radius: 4px;">
            <div class="d-flex align-items-center mb-3">
                <i class="bi bi-envelope-fill text-primary me-2 fs-5"></i>
                <h6 class="fw-bold m-0 text-dark">Email</h6>
            </div>
            <div class="bg-white text-muted" style="border: 1px solid #eaedf1; font-size: 13px; border-radius: 4px;">
                <div class="p-3 border-bottom d-flex"><strong class="text-dark me-2" style="width: 100px;">Billing:</strong> <?= CONTACT_BILLING ?></div>
                <div class="p-3 border-bottom d-flex"><strong class="text-dark me-2" style="width: 100px;">Email/Kontak:</strong> <?= CONTACT_INFO ?></div>
                <div class="p-3 d-flex"><strong class="text-dark me-2" style="width: 100px;">Support Teknis:</strong> <?= CONTACT_SUPPORT ?></div>
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../../library/footer.php'; ?>
