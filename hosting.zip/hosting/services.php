<?php
if(!defined('NS1')) include __DIR__ . '/../config/database.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }

require_once __DIR__ . '/../library/session.php';

$user_id = $_SESSION['user_id'];
$query_user = mysqli_query($conn, "SELECT * FROM users WHERE id = '$user_id'");
$u = mysqli_fetch_assoc($query_user);

$products = [
    [
        'id' => 1,
        'name' => 'Starter Cloud',
        'price' => 15000,
        'discount' => 25000,
        'storage' => '1 GB SSD',
        'bandwidth' => 'Unlimited',
        'domain' => '1 Domain',
        'info' => 'Cocok untuk blog pribadi.',
        'badge' => '',
        'icon' => 'bi-window-stack'
    ],
    [
        'id' => 2,
        'name' => 'Business Pro',
        'price' => 45000,
        'discount' => 75000,
        'storage' => '10 GB NVMe',
        'bandwidth' => 'Unlimited',
        'domain' => '5 Domain',
        'info' => 'Terlaris untuk UMKM.',
        'badge' => 'POPULAR',
        'icon' => 'bi-wordpress'
    ],
    [
        'id' => 3,
        'name' => 'Enterprise SQL',
        'price' => 120000,
        'discount' => 200000,
        'storage' => 'Unlimited',
        'bandwidth' => 'Dedicated',
        'domain' => 'Unlimited',
        'info' => 'Performa trafik tinggi.',
        'badge' => 'ULTIMATE',
        'icon' => 'bi-cloud-check'
    ]
];

$page_title = "Pesan Hosting";
include __DIR__ . '/../library/header.php';
?>

<!-- Clean Wrapper exact like image -->
<div class="card border-0 shadow-sm mb-4" style="background: white; border-radius: 4px;">
    
    <div class="card-header bg-white d-flex align-items-center" style="padding: 1.25rem 1.5rem; border-bottom: 1px solid var(--border-color);">
        <i class="bi bi-hdd-stack text-primary me-2 fs-5"></i>
        <span class="fw-bold fs-6 text-dark">Layanan Baru (Hosting)</span>
    </div>
    
    <div class="card-body p-4" style="background: #fdfdfd;">
        <div class="row g-4 justify-content-center">
            <?php foreach ($products as $p): ?>
            <div class="col-lg-4 col-md-6">
                <!-- Product Card mimicking image exactly -->
                <div class="product-card card h-100 p-4 border shadow-sm position-relative text-center hover-card" style="border-radius: 4px; border-color: #eaedf1 !important;">
                    
                    <?php if (!empty($p['badge'])): ?>
                    <span class="position-absolute top-0 end-0 px-2 py-1 text-uppercase fw-bold text-white" 
                          style="background: #ffaa00; font-size: 0.55rem; letter-spacing: 1px; border-bottom-left-radius: 4px;">
                        <?php echo $p['badge']; ?>
                    </span>
                    <?php endif; ?>

                    <div class="mb-2">
                        <!-- Big light cyan outline icon -->
                        <i class="bi <?php echo $p['icon']; ?>" style="font-size: 3.5rem; color: #48cae4; font-weight: 300;"></i>
                    </div>
                    
                    <!-- Buttons exactly below icon -->
                    <div class="d-flex justify-content-center gap-2 mb-3">
                        <a href="<?= base_url('hosting/order/'.$p['id']) ?>" class="btn btn-sm text-white px-3 d-flex align-items-center" style="background: #20c997; border-radius: 20px; font-size: 0.70rem; font-weight: 600;">
                            <i class="bi bi-cart me-1"></i> Pesan
                        </a>
                        <button type="button" class="btn btn-outline-primary btn-sm px-3 d-flex align-items-center" style="border-radius: 20px; font-size: 0.70rem; font-weight: 600;">
                            Info <i class="bi bi-chevron-right ms-1" style="font-size: 0.55rem;"></i>
                        </button>
                    </div>

                    <h6 class="fw-bold text-secondary mb-1" style="font-size: 1rem;"><?php echo $p['name']; ?></h6>
                    <div class="text-muted small mb-4">Mulai <span class="fw-bold text-dark">Rp <?php echo number_format($p['price'], 0, ',', '.'); ?></span> / bln</div>
                    
                    <div class="features-text text-start mt-auto text-secondary" style="font-size: 0.75rem; border-top: 1px solid #eaedf1; padding-top: 15px;">
                        <div class="d-flex justify-content-between mb-2">
                            <span><i class="bi bi-database me-1 text-muted"></i> Storage:</span> 
                            <span class="fw-bold text-dark"><?php echo $p['storage']; ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span><i class="bi bi-activity me-1 text-muted"></i> Bandwidth:</span> 
                            <span class="fw-bold text-dark"><?php echo $p['bandwidth']; ?></span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span><i class="bi bi-globe me-1 text-muted"></i> Domain:</span> 
                            <span class="fw-bold text-dark"><?php echo $p['domain']; ?></span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span><i class="bi bi-shield-check me-1 text-muted"></i> Fitur:</span> 
                            <span class="fw-bold text-dark">SSL & Backup</span>
                        </div>
                    </div>

                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Bottom table representation -->
<div class="card border-0 shadow-sm" style="background: white; border-radius: 4px;">
    <div class="card-header bg-white" style="padding: 1.25rem 1.5rem; border-bottom: 1px solid var(--border-color);">
        <span class="fw-bold fs-6 text-dark">Bantuan Ahli</span>
    </div>
    <div class="card-body p-4">
        
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
            <div class="d-flex align-items-center">
                <i class="bi bi-headset text-muted" style="font-size: 2.5rem; opacity: 0.5;"></i>
                <div class="ms-3">
                    <span class="fw-bold text-dark d-block">Kesulitan menentukan batas Storage atau Trafik?</span>
                    <span class="text-secondary small">Konsultasikan langsung dengan teknisi kami yang akan online 24/7.</span>
                </div>
            </div>
            
            <div>
                <button class="btn btn-sm btn-primary px-4 fw-medium" style="border-radius: 4px;">Live Chat</button>
            </div>
        </div>
        
    </div>
</div>

<style>
    .hover-card { transition: all 0.2s ease; box-shadow: 0 2px 5px rgba(0,0,0,0.02) !important; }
    .hover-card:hover { transform: translateY(-3px); box-shadow: 0 8px 20px rgba(0,0,0,0.05) !important; border-color: #ccd4df !important; }
    .btn-outline-primary { border-color: #007bff; color: #007bff; }
    .btn-outline-primary:hover { background: #007bff; color: white; }
</style>

<?php include __DIR__ . '/../library/footer.php'; ?>
