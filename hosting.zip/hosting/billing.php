<?php
if(!defined('NS1')) include __DIR__ . '/../config/database.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }

if (!isset($_SESSION['user_id'])) {
    header("Location: /auth/login");
    exit;
}

$user_id = $_SESSION['user_id'];

// Get counts
$query_counts = mysqli_query($conn, "
    SELECT 
        COUNT(id) as total_any,
        SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) as total_paid,
        SUM(CASE WHEN status = 'unpaid' THEN 1 ELSE 0 END) as total_unpaid,
        SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as total_cancelled
    FROM invoices 
    WHERE user_id = '$user_id'
");
$counts = mysqli_fetch_assoc($query_counts);

// Get total due
$query_due = mysqli_query($conn, "
    SELECT COUNT(id) as count_due, SUM(total_tagihan) as sum_due 
    FROM invoices 
    WHERE user_id = '$user_id' AND status = 'unpaid'
");
$due = mysqli_fetch_assoc($query_due);

$filter = isset($_GET['status']) ? $_GET['status'] : 'any';
$where_status = "";
$title_filter = "Any";
if ($filter == 'paid') { $where_status = "AND status = 'paid'"; $title_filter = "Paid"; }
if ($filter == 'unpaid') { $where_status = "AND status = 'unpaid'"; $title_filter = "Unpaid"; }
if ($filter == 'cancelled') { $where_status = "AND status = 'cancelled'"; $title_filter = "Cancelled"; }

// Get invoices
$sql = "SELECT id, date_created, date_due, status, total_tagihan FROM invoices WHERE user_id = '$user_id' $where_status ORDER BY date_created DESC";
$invoices = mysqli_query($conn, $sql);

$page_title = "Invoices";
include __DIR__ . '/../library/header.php';
?>

<style>
    .card { border: none; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.03); background: #fff; margin-bottom: 20px; }
    .card-header { background: #fff; border-bottom: 1px solid var(--border-color); padding: 1.25rem 1.5rem; }
    .card-body { padding: 1.5rem; }
    
    .status-list { list-style: none; padding: 0; margin: 0; }
    .status-list li { padding: 10px 0; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; justify-content: space-between; cursor: pointer; transition: 0.2s; }
    .status-list li:last-child { border-bottom: none; }
    .status-list li:hover { background: #fdfdfd; }
    .status-list a { text-decoration: none; color: #4a5568; display: flex; align-items: center; width: 100%; justify-content: space-between; }
    
    .status-radio { width: 14px; height: 14px; border-radius: 50%; border: 1px solid #ccc; display: inline-block; margin-right: 10px; position: relative; }
    .status-list li.active .status-radio { border-color: #007bff; }
    .status-list li.active .status-radio::after { content: ''; width: 8px; height: 8px; background: #007bff; border-radius: 50%; position: absolute; top: 2px; left: 2px; }
    .status-list li.active a { color: #007bff; font-weight: 600; }
    
    .badge-count { background: #e2e8f0; color: #4a5568; font-size: 0.75rem; font-weight: 600; padding: 2px 8px; border-radius: 12px; }
    
    .table-invoice th { font-weight: 600; color: #4a5568; font-size: 0.8rem; border-bottom: 1px solid #e2e8f0; padding-bottom: 15px; }
    .table-invoice td { padding: 15px 10px; vertical-align: middle; border-bottom: 1px solid #f8fafc; font-size: 0.85rem; color: #4a5568; }
    
    .btn-status { font-size: 0.75rem; padding: 4px 15px; border-radius: 4px; font-weight: 600; text-transform: capitalize; background: transparent; border: 1px solid #ccc; }
    .btn-status.unpaid { border-color: #fca5a5; color: #ef4444; }
    .btn-status.paid { border-color: #86efac; color: #22c55e; }
    .btn-status.cancelled { border-color: #d1d5db; color: #6b7280; }
    
    .deposit-text { color: #22c55e; font-weight: 700; }
    .due-text { color: #ef4444; font-weight: 700; }
    
    .pagination-custom .page-link { border: 1px solid #e2e8f0; color: #4a5568; font-size: 0.8rem; padding: 5px 12px; }
    .pagination-custom .page-item.active .page-link { background: #007bff; border-color: #007bff; color: white; }
</style>

<div class="row">
    <!-- Left Sidebar Widgets -->
    <div class="col-lg-3">
        
        <!-- Status Filter Box -->
        <div class="card">
            <div class="card-header fw-bold text-dark fs-6" style="border-bottom: none; padding-bottom: 5px;">Status</div>
            <div class="card-body pt-0">
                <ul class="status-list mt-3">
                    <li class="<?= $filter == 'any' ? 'active' : '' ?>">
                        <a href="?status=any">
                            <div><span class="status-radio"></span> Any</div>
                            <span class="badge-count"><?= (int)$counts['total_any'] ?></span>
                        </a>
                    </li>
                    <li class="<?= $filter == 'paid' ? 'active' : '' ?>">
                        <a href="?status=paid">
                            <div><span class="status-radio"></span> Paid</div>
                            <span class="badge-count"><?= (int)$counts['total_paid'] ?></span>
                        </a>
                    </li>
                    <li class="<?= $filter == 'unpaid' ? 'active' : '' ?>">
                        <a href="?status=unpaid">
                            <div><span class="status-radio"></span> Unpaid</div>
                            <span class="badge-count"><?= (int)$counts['total_unpaid'] ?></span>
                        </a>
                    </li>
                    <li class="<?= $filter == 'cancelled' ? 'active' : '' ?>">
                        <a href="?status=cancelled">
                            <div><span class="status-radio"></span> Cancelled</div>
                            <span class="badge-count"><?= (int)$counts['total_cancelled'] ?></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Deposit Box -->
        <div class="card">
            <div class="card-header fw-bold text-dark fs-6" style="border-bottom: none; padding-bottom: 10px;">Deposit</div>
            <div class="card-body pt-0 small text-muted">
                Anda memiliki deposit sejumlah <span class="deposit-text">Rp 0,00</span>
            </div>
        </div>
        
        <!-- Due Invoices Box -->
        <div class="card">
            <div class="card-header fw-bold text-dark fs-6" style="border-bottom: none; padding-bottom: 10px;">
                <?= (int)$due['count_due']; ?> Invoice Jatuh Tempo
            </div>
            <div class="card-body pt-0 small text-muted">
                <?php if ($due['count_due'] > 0): ?>
                    Anda memiliki <?= (int)$due['count_due']; ?> invoice belum lunas dengan total tagihan sejumlah 
                    <span class="due-text">Rp <?= number_format($due['sum_due'], 0, ',', '.'); ?></span>
                <?php else: ?>
                    Anda tidak memiliki invoice yang sedang jatuh tempo.
                <?php endif; ?>
            </div>
        </div>

    </div>
    
    <!-- Main Right Content -->
    <div class="col-lg-9">
        <div class="card h-100">
            <div class="card-header fw-bold text-dark fs-6">
                Daftar Invoice <?= $title_filter ?>
            </div>
            <div class="card-body">
                
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div class="d-flex align-items-center text-muted small">
                        Tampilkan &nbsp;
                        <select class="form-select border shadow-none form-select-sm" style="width: 70px;">
                            <option>10</option>
                            <option>25</option>
                        </select>
                        &nbsp; Entri
                    </div>
                    <div class="d-flex">
                        <input type="text" class="form-control form-control-sm shadow-none border" placeholder="ID Invoice...">
                        <button class="btn btn-primary btn-sm ms-2 px-3 fw-medium">Cari</button>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-invoice table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tanggal Invoice</th>
                                <th>Jatuh Tempo</th>
                                <th>Total</th>
                                <th class="text-center">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($invoices) > 0): ?>
                                <?php while($row = mysqli_fetch_assoc($invoices)): 
                                    $inv_id = $row['id'];
                                    $date_inv = date('Y-m-d', strtotime($row['date_created']));
                                    $date_due = date('Y-m-d', strtotime($row['date_due']));
                                    
                                    $status_html = '<button class="btn-status cancelled">Cancelled</button>';
                                    if ($row['status'] == 'unpaid') {
                                        $status_html = '<button class="btn-status unpaid">Unpaid</button>';
                                    } elseif ($row['status'] == 'paid') {
                                        $status_html = '<button class="btn-status paid">Paid</button>';
                                    }
                                ?>
                                <tr onclick="window.location='<?= base_url("hosting/invoice/$inv_id") ?>'" style="cursor: pointer;">
                                    <td>
                                        <span class="text-primary fw-medium text-decoration-none">
                                            #<?= $inv_id ?>
                                        </span>
                                    </td>
                                    <td><?= $date_inv ?></td>
                                    <td><?= $date_due ?></td>
                                    <td class="text-dark fw-medium">Rp <?= number_format($row['total_tagihan'], 2, ',', '.') ?></td>
                                    <td class="text-center"><?= $status_html ?></td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">Belum ada invoice.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="d-flex justify-content-end mt-4">
                    <ul class="pagination pagination-sm pagination-custom m-0">
                        <li class="page-item disabled"><a class="page-link" href="#">First</a></li>
                        <li class="page-item disabled"><a class="page-link" href="#">Prev</a></li>
                        <li class="page-item active"><a class="page-link" href="#">1</a></li>
                        <li class="page-item disabled"><a class="page-link" href="#">Next</a></li>
                        <li class="page-item disabled"><a class="page-link" href="#">Last</a></li>
                    </ul>
                </div>
                
            </div>
        </div>
    </div>
</div>

<?php include __DIR__ . '/../library/footer.php'; ?>
