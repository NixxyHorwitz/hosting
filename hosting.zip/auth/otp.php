<?php
if (!defined('NS1')) { 
    if(!defined('NS1')) include __DIR__ . '/../config/database.php';
}

if (isset($_SESSION['user_id'])) {
    header("Location: /hosting"); 
    exit();
}

$otpsession = isset($_GET['id']) ? $_GET['id'] : '';
if (empty($otpsession) || !isset($_SESSION['otp_session']) || $_SESSION['otp_session'] !== $otpsession) {
    header("Location: /auth/login");
    exit();
}

$message_type = "";
$message_text = "";
$user_id = $_SESSION['otp_user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['verify_otp'])) {
    $otp_input = mysqli_real_escape_string($conn, $_POST['otp']);

    $q = mysqli_query($conn, "SELECT id, otp_code, otp_expiry FROM users WHERE id = '$user_id'");
    if (mysqli_num_rows($q) > 0) {
        $user = mysqli_fetch_assoc($q);
        if ($user['otp_code'] === $otp_input) {
            if (strtotime($user['otp_expiry']) > time()) {
                // OTP valid
                mysqli_query($conn, "UPDATE users SET status = 'active', otp_code = NULL, otp_expiry = NULL WHERE id = '$user_id'");
                $message_type = "success";
                unset($_SESSION['otp_session']);
                unset($_SESSION['otp_user_id']);
            } else {
                $message_type = "error";
                $message_text = "Kode OTP sudah kedaluwarsa.";
            }
        } else {
            $message_type = "error";
            $message_text = "Kode OTP tidak valid.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi OTP - SobatHosting</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        :root { --primary: #0d6efd; --bg: #f4f7fa; }
        body { background-color: var(--bg); font-family: 'Inter', sans-serif; display: flex; align-items: center; padding: 40px 0; min-height:100vh;}
        .auth-card { border: none; border-radius: 24px; box-shadow: 0 15px 35px rgba(0,0,0,0.08); overflow: hidden; background: #fff; padding:30px; text-align:center; }
        .form-control { border-radius: 12px; padding: 12px 15px; border: 1px solid #e0e6ed; background: #f9fbff; text-align:center; font-size:24px; letter-spacing:10px; font-weight:bold;}
        .form-control:focus { box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1); border-color: var(--primary); }
        .btn-auth { border-radius: 12px; padding: 12px; font-weight: 700; letter-spacing: 0.5px; transition: 0.3s; }
        .btn-auth:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(13, 110, 253, 0.3); }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card auth-card">
                <h4 class="mb-3 fw-bold">Verifikasi Email Anda</h4>
                <p class="text-muted small">Kami telah mengirimkan 6 digit kode OTP ke email Anda. Masukkan kode tersebut di bawah ini.</p>
                
                <form action="" method="POST" class="mt-4">
                    <div class="mb-4">
                        <input type="text" name="otp" class="form-control" maxlength="6" placeholder="------" required>
                    </div>
                    <button type="submit" name="verify_otp" class="btn btn-primary w-100 btn-auth">VERIFIKASI</button>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
<?php if($message_type == "success"): ?>
    Swal.fire({
        icon: 'success',
        title: 'Verifikasi Berhasil!',
        text: 'Akun Anda telah aktif, silakan login.',
        confirmButtonColor: '#0d6efd'
    }).then(() => { window.location.href = '/auth/login'; });
<?php elseif($message_type == "error"): ?>
    Swal.fire({
        icon: 'error',
        title: 'Opps!',
        text: '<?php echo $message_text; ?>',
        confirmButtonColor: '#0d6efd'
    });
<?php endif; ?>
</script>
</body>
</html>
