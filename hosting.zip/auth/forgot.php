<?php
if(!defined('NS1')) include __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../core/api_helper.php';
require_once __DIR__ . '/../core/mailer.php';

if (isset($_SESSION['user_id'])) {
    header("Location: /hosting"); 
    exit();
}

$message_type = "";
$message_text = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['forgot'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    
    $q = mysqli_query($conn, "SELECT id, nama FROM users WHERE email = '$email'");
    if (mysqli_num_rows($q) > 0) {
        $user = mysqli_fetch_assoc($q);
        
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        mysqli_query($conn, "UPDATE users SET reset_token = '$token', reset_expiry = '$expiry' WHERE id = '{$user['id']}'");
        
        $reset_link = base_url('auth/reset/' . $token);
        
        sendEmailTemplate($email, $user['nama'], 'forgot_password', [
            'nama' => $user['nama'],
            'reset_link' => $reset_link
        ]);
        
        $message_type = "success";
    } else {
        $message_type = "error";
        $message_text = "Email tidak ditemukan.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lupa Password - SobatHosting</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        :root { --primary: #0d6efd; --bg: #f4f7fa; }
        body { background-color: var(--bg); font-family: 'Inter', sans-serif; display: flex; align-items: center; padding: 40px 0; min-height:100vh;}
        .auth-card { border: none; border-radius: 24px; box-shadow: 0 15px 35px rgba(0,0,0,0.08); overflow: hidden; background: #fff; padding:30px; }
        .form-control { border-radius: 12px; padding: 12px 15px; border: 1px solid #e0e6ed; background: #f9fbff;}
        .form-control:focus { box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1); border-color: var(--primary); }
        .btn-auth { border-radius: 12px; padding: 12px; font-weight: 700; letter-spacing: 0.5px; transition: 0.3s; }
        .btn-auth:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(13, 110, 253, 0.3); }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card auth-card">
                <h4 class="mb-3 fw-bold text-center">Lupa Password</h4>
                <p class="text-muted small text-center">Masukkan email yang terdaftar, kami akan mengirimkan link untuk mereset password Anda.</p>
                
                <form action="" method="POST" class="mt-4">
                    <div class="mb-4">
                        <input type="email" name="email" class="form-control" placeholder="nama@email.com" required>
                    </div>
                    <button type="submit" name="forgot" class="btn btn-primary w-100 btn-auth">KIRIM LINK RECOVERY</button>
                    <p class="text-center mt-4 small"><a href="/auth/login" class="text-decoration-none fw-bold">Kembali ke Login</a></p>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
<?php if($message_type == "success"): ?>
    Swal.fire({
        icon: 'success',
        title: 'Terkirim!',
        text: 'Cek email Anda untuk link reset password (jika alamat email terdaftar).',
        confirmButtonColor: '#0d6efd'
    }).then(() => { window.location.href = '/auth/login'; });
<?php elseif($message_type == "error"): ?>
    Swal.fire({
        icon: 'error',
        title: 'Opps!',
        text: '<?php echo $message_text; ?>',
        confirmButtonColor: '#0d6efd'
    });
<?php endif; ?>
</script>
</body>
</html>
