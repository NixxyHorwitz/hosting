<?php
if (!defined('NS1')) { 
    if(!defined('NS1')) include __DIR__ . '/../config/database.php';
}

if (isset($_SESSION['user_id'])) {
    header("Location: /hosting"); 
    exit();
}

$token = isset($_GET['id']) ? $_GET['id'] : '';
if (empty($token)) {
    die("Invalid Reset Token");
}

$message_type = "";
$message_text = "";
$valid_token = false;

$q = mysqli_query($conn, "SELECT id, reset_expiry FROM users WHERE reset_token = '$token'");
if (mysqli_num_rows($q) > 0) {
    $user = mysqli_fetch_assoc($q);
    if (strtotime($user['reset_expiry']) > time()) {
        $valid_token = true;
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reset'])) {
            $new_pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
            mysqli_query($conn, "UPDATE users SET password = '$new_pass', reset_token = NULL, reset_expiry = NULL WHERE id = '{$user['id']}'");
            $message_type = "success";
        }
    } else {
        $message_text = "Token reset password sudah kedaluwarsa.";
    }
} else {
    $message_text = "Token reset password tidak valid.";
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - SobatHosting</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        :root { --primary: #0d6efd; --bg: #f4f7fa; }
        body { background-color: var(--bg); font-family: 'Inter', sans-serif; display: flex; align-items: center; padding: 40px 0; min-height:100vh;}
        .auth-card { border: none; border-radius: 24px; box-shadow: 0 15px 35px rgba(0,0,0,0.08); overflow: hidden; background: #fff; padding:30px; }
        .form-control { border-radius: 12px; padding: 12px 15px; border: 1px solid #e0e6ed; background: #f9fbff;}
        .form-control:focus { box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1); border-color: var(--primary); }
        .btn-auth { border-radius: 12px; padding: 12px; font-weight: 700; letter-spacing: 0.5px; transition: 0.3s; }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card auth-card">
                <h4 class="mb-3 fw-bold text-center">Buat Password Baru</h4>
                <?php if ($valid_token && empty($message_type)): ?>
                    <form action="" method="POST" class="mt-4">
                        <div class="mb-4">
                            <label class="form-label small fw-bold text-muted">Password Baru</label>
                            <input type="password" name="password" minlength="6" class="form-control" placeholder="Minimal 6 karakter" required>
                        </div>
                        <button type="submit" name="reset" class="btn btn-primary w-100 btn-auth">SIMPAN PASSWORD</button>
                    </form>
                <?php elseif ($message_type == 'success'): ?>
                    <div class="alert alert-success text-center">
                        Password berhasil diperbarui. <br><br>
                        <a href="/auth/login" class="btn btn-primary btn-sm">Login Sekarang</a>
                    </div>
                <?php else: ?>
                    <div class="alert alert-danger text-center">
                        <?php echo $message_text; ?> <br><br>
                        <a href="/auth/forgot" class="btn btn-primary btn-sm">Meminta Token Baru</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>
