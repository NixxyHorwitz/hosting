<?php
if (!defined('NS1')) { // Basic check if DB was loaded (from config/database.php)
    if(!defined('NS1')) include __DIR__ . '/../config/database.php';
}

if (isset($_SESSION['user_id'])) {
    header("Location: /hosting"); 
    exit();
}

$message_type = "";
$message_text = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM users WHERE email = '$email'");
    if (mysqli_num_rows($query) > 0) {
        $user = mysqli_fetch_assoc($query);
        if (password_verify($password, $user['password'])) {
            if ($user['status'] !== 'active') {
                $message_type = "error";
                $message_text = "Akun belum aktif. Silakan verifikasi email Anda.";
            } else {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_nama'] = $user['nama'];
                $message_type = "success_login";
            }
        } else {
            $message_type = "error";
            $message_text = "Password yang Anda masukkan salah.";
        }
    } else {
        $message_type = "error";
        $message_text = "Email tidak ditemukan.";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk - SobatHosting</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        :root { 
            --primary: #4461F2; 
            --bg: #ffffff; 
            --text-dark: #333333;
            --text-muted: #888888;
        }
        body, html {
            height: 100%;
            margin: 0;
            font-family: 'Inter', sans-serif;
            background-color: var(--bg);
        }
        .full-screen {
            height: 100vh;
            display: flex;
        }
        .left-pane {
            background: linear-gradient(135deg, #4461F2 0%, #2A3FBA 100%);
            color: #fff;
            width: 40%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 40px 50px;
            position: relative;
            overflow: hidden;
        }
        .left-pane::before {
            content: '';
            position: absolute;
            top: -20%;
            left: -20%;
            width: 150%;
            height: 150%;
            background: url('data:image/svg+xml;utf8,<svg width="100%" height="100%" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg"><path d="M0,0 L100,100 M20,0 L120,100 M40,0 L140,100" stroke="rgba(255,255,255,0.05)" stroke-width="2" /></svg>');
            background-size: cover;
            z-index: 0;
            pointer-events: none;
        }
        .left-pane > * {
            z-index: 1;
            position: relative;
        }
        .left-pane h2 {
            font-weight: 700;
            margin-bottom: 20px;
        }
        .left-pane p {
            opacity: 0.9;
            font-weight: 300;
            line-height: 1.6;
        }
        .right-pane {
            width: 60%;
            display: flex;
            flex-direction: column;
            padding: 30px;
            position: relative;
        }
        .top-right {
            align-self: flex-end;
            font-size: 0.9rem;
            color: var(--text-muted);
        }
        .form-container {
            margin: auto;
            width: 100%;
            max-width: 400px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .form-title {
            text-align: center;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 40px;
            font-size: 1.8rem;
        }
        .form-control {
            border: 1px solid #E0E0E0;
            border-radius: 4px;
            padding: 12px 15px;
            box-shadow: none;
            background: #FAFAFA;
        }
        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 2px rgba(68, 97, 242, 0.1);
            background: #fff;
        }
        .input-group-text {
            background: #FAFAFA;
            border: 1px solid #E0E0E0;
            border-left: none;
            cursor: pointer;
        }
        .action-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
        }
        .btn-masuk {
            background-color: var(--primary);
            color: #fff;
            border: none;
            padding: 10px 40px;
            border-radius: 4px;
            font-weight: 600;
            transition: 0.3s;
        }
        .btn-masuk:hover {
            background-color: #364fc7;
            color: #fff;
        }
        .lupa-password {
            color: var(--primary);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            border: 1px solid rgba(68, 97, 242, 0.3);
            padding: 8px 15px;
            border-radius: 4px;
        }
        .divider {
            display: flex;
            align-items: center;
            text-align: center;
            color: #bbb;
            margin: 30px 0;
            font-size: 0.8rem;
        }
        .divider::before, .divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid #E0E0E0;
        }
        .divider:not(:empty)::before {
            margin-right: 15px;
        }
        .divider:not(:empty)::after {
            margin-left: 15px;
        }
        .btn-google {
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #4285F4;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 4px;
            width: 100%;
            font-weight: 600;
            transition: 0.3s;
            text-decoration: none;
        }
        .btn-google:hover {
            background-color: #357ae8;
            color: #fff;
        }
        .google-icon-wrapper {
            background: #fff;
            padding: 6px;
            border-radius: 2px;
            margin-right: 10px;
            display: flex;
        }
        
        @media (max-width: 900px) {
            .left-pane { display: none; }
            .right-pane { width: 100%; }
        }
    </style>
</head>
<body>

<div class="full-screen">
    <!-- Kolom Kiri -->
    <div class="left-pane">
        <div>
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L2 7L12 12L22 7L12 2Z" fill="white"/>
                <path d="M2 17L12 22L22 17V12L12 17L2 12V17Z" fill="white" fill-opacity="0.5"/>
                <path d="M2 12L12 17L22 12V7L12 12L2 7V12Z" fill="white" fill-opacity="0.8"/>
            </svg>
        </div>
        
        <div class="mb-5">
            <h2>Selamat Datang di <?= htmlspecialchars(SITE_NAME) ?>!</h2>
            <p>Didirikan pada tahun 2026, <?= htmlspecialchars(SITE_NAME) ?> Indonesia tumbuh menjadi salah satu perusahaan hosting terbaik yang kini siap melayani impian digital pelanggan.</p>
        </div>

        <div class="d-flex justify-content-between align-items-center" style="font-size:0.8rem; font-weight:300;">
            <div>&copy; 2026 <?= htmlspecialchars(SITE_NAME) ?></div>
            <div class="d-flex gap-3">
                <span>Privasi</span>
                <span>Legal</span>
                <span>Kontak</span>
            </div>
        </div>
    </div>

    <!-- Kolom Kanan -->
    <div class="right-pane">
        <div class="top-right">
            Belum punya akun? <a href="/auth/register" style="color:var(--primary); text-decoration:none; font-weight:600;">Daftar</a>
        </div>
        
        <div class="form-container">
            <h3 class="form-title">Masuk Akun</h3>
            
            <form action="" method="POST">
                <div class="mb-3">
                    <input type="email" name="email" class="form-control" placeholder="Masukkan email Anda" required>
                </div>
                
                <div class="input-group mb-2">
                    <input type="password" name="password" id="loginPass" class="form-control" style="border-right: none;" placeholder="••••••••" required>
                    <span class="input-group-text" onclick="togglePassword('loginPass')">
                        <i class="bi bi-eye-slash text-muted" id="iconPass"></i>
                    </span>
                </div>
                
                <div class="action-row">
                    <a href="/auth/forgot" class="lupa-password">Lupa Password?</a>
                    <button type="submit" name="login" class="btn btn-masuk">Masuk</button>
                </div>
            </form>

            <div class="divider">ATAU</div>

            <a href="#" class="btn-google">
                <div class="google-icon-wrapper">
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="18px" height="18px" viewBox="0 0 48 48">
                        <g><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path><path fill="none" d="M0 0h48v48H0z"></path></g>
                    </svg>
                </div>
                <span>Sign In with Google</span>
            </a>
            
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function togglePassword(id) {
    const input = document.getElementById(id);
    const icon = document.getElementById('iconPass');
    if (input.type === "password") {
        input.type = "text";
        icon.classList.replace('bi-eye-slash', 'bi-eye');
    } else {
        input.type = "password";
        icon.classList.replace('bi-eye', 'bi-eye-slash');
    }
}
<?php if($message_type == "success_login"): ?>
    Swal.fire({
        icon: 'success',
        title: 'Berhasil Masuk!',
        text: 'Selamat datang kembali, <?php echo $_SESSION['user_nama']; ?>',
        timer: 1500,
        showConfirmButton: false
    }).then(() => { window.location.href = '/hosting'; });
<?php elseif($message_type == "error"): ?>
    Swal.fire({
        icon: 'error',
        title: 'Opps!',
        text: '<?php echo $message_text; ?>',
        confirmButtonColor: '#4461F2'
    });
<?php endif; ?>
</script>
</body>
</html>
