    </div> <!-- End of content-container -->
    
    <!-- Clean Footer exact like image -->
    <footer class="mt-auto py-3 px-4 bg-white" style="border-top: 1px solid var(--border-color); font-size: 0.75rem; color: #888888;">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
            <div>
                <?= date("Y") ?> &copy; SobatHosting Indonesia
            </div>
            <div class="d-flex gap-3">
                <a href="#" class="text-muted text-decoration-none hover-blue">About</a>
                <a href="#" class="text-muted text-decoration-none hover-blue">Team</a>
                <a href="#" class="text-muted text-decoration-none hover-blue">Contact</a>
            </div>
        </div>
    </footer>
</div> <!-- End of main-content -->

<style>
    .hover-blue:hover { color: #007bff !important; }
</style>

<!-- Floating Live Support Button -->
<a href="#" class="position-fixed shadow d-flex align-items-center justify-content-center" style="bottom: 20px; right: 20px; width: 50px; height: 50px; border-radius: 50%; background: #4a7dff; color: white; z-index: 9999; text-decoration: none;">
    <i class="bi bi-chat-fill fs-4"></i>
</a>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
