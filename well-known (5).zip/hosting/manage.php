<?php
session_start();
require_once '../config/database.php';
require_once '../core/WHMClient.php';

if (!isset($_SESSION['user_id'])) {
    die("❌ Silakan login dulu");
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("❌ ID tidak valid");
}

$id = (int) $_GET['id'];
$user_id = (int) $_SESSION['user_id'];

$query = mysqli_query($conn, "SELECT * FROM orders WHERE id = '$id' AND user_id = '$user_id' LIMIT 1");
$row_order = mysqli_fetch_assoc($query);

if (!$row_order) {
    die("❌ Data hosting tidak ditemukan.");
}

// --- AMBIL STATISTIK REAL-TIME DARI WHM ---
$whm = new WHMClient();
try {

    $stats = $whm->getClientStats($row_order['username']);
     
    $disk_used = $stats['disk']['used'];
    $disk_limit = $stats['disk']['limit'];
    $disk_percent = $stats['disk']['percent'];

    $bw_used = $stats['bandwidth']['used'];
    $bw_limit = $stats['bandwidth']['limit'];
    $bw_percent = $stats['bandwidth']['percent'];
} catch (Exception $e) {
    // Jika API gagal (misal server down), gunakan nilai default agar page tidak error
    $disk_used = 0; $disk_limit = "N/A"; $disk_percent = 0;
    $bw_used = 0; $bw_limit = "N/A"; $bw_percent = 0;
    $api_error = $e->getMessage();
}
include '../library/header.php';
?>

<style>
    :root {
        --rw-blue: #0056b3;
        --rw-green: #28a745;
        --rw-light: #f4f7f6;
        --rw-border: #e1e4e8;
    }

    body { background-color: var(--rw-light); font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; }
    
    .breadcrumb { background: transparent; padding: 0; margin-bottom: 20px; }
    .breadcrumb-item a { color: var(--rw-blue); text-decoration: none; font-size: 13px; }

    .card-rw { 
        border: 1px solid var(--rw-border); 
        border-radius: 8px; 
        box-shadow: 0 2px 4px rgba(0,0,0,0.02);
        margin-bottom: 1.5rem;
        background: #fff;
    }
    
    .card-rw .card-header {
        background-color: #fff;
        border-bottom: 1px solid var(--rw-border);
        padding: 15px 20px;
        font-weight: 700;
        color: #333;
    }

    /* Sidebar Styles */
    .list-group-rw .list-group-item {
        border: none;
        padding: 10px 0;
        font-size: 14px;
        color: #555;
    }
    .list-group-rw .list-group-item:hover { color: var(--rw-blue); background: transparent; }

    /* Stats Progress Bars (Lebih Modern dari Circle) */
    .usage-label { font-size: 12px; font-weight: 600; color: #666; margin-bottom: 5px; display: flex; justify-content: space-between; }
    .progress { height: 8px; border-radius: 10px; margin-bottom: 15px; }

    /* Shortcut Grid */
    .cpanel-shortcut {
        text-align: center;
        padding: 15px 10px;
        border-radius: 8px;
        transition: all 0.2s;
        text-decoration: none !important;
        display: block;
        color: #444 !important;
        font-size: 12px;
        border: 1px solid transparent;
    }
    .cpanel-shortcut:hover {
        background: #f0f7ff;
        border-color: #d0e3ff;
        transform: translateY(-3px);
    }
    .cpanel-shortcut img {
        width: 38px;
        height: 38px;
        margin-bottom: 10px;
        filter: grayscale(10%) contrast(90%);
    }

    .btn-rw-primary { background: var(--rw-blue); color: #fff; border: none; padding: 8px 20px; border-radius: 5px; font-size: 14px; }
    .btn-rw-outline { border: 1px solid var(--rw-border); color: #555; padding: 8px 20px; border-radius: 5px; font-size: 14px; background: #fff; }
    .btn-rw-primary:hover { background: #004494; color: #fff; }
    
    .status-badge {
        background: #e7f4e9;
        color: #28a745;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 600;
    }
</style>

<div class="container py-5">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Portal Home</a></li>
            <li class="breadcrumb-item"><a href="#">Client Area</a></li>
            <li class="breadcrumb-item active text-muted">Hosting Details</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-3">
            <div class="card-rw p-4">
                <h6 class="fw-bold mb-3">Actions</h6>
                <div class="list-group list-group-rw">
                    <a href="#" class="list-group-item"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
                    <a href="<?= base_url('hosting/cpanel?id=' . $id) ?>" target="_blank" class="list-group-item text-primary fw-bold">
                        <i class="bi bi-box-arrow-in-right me-2"></i> Login to cPanel
                    </a>
                    <a href="<?= base_url('hosting/webmail?id=' . $id) ?>" target="_blank" class="list-group-item">
                        <i class="bi bi-envelope me-2"></i> Login to Webmail
                    </a>
                </div>
            </div>

            <div class="card-rw p-4">
                <h6 class="fw-bold mb-3">Usage Statistics</h6>
                
                <div class="usage-item">
                    <div class="usage-label">
                        <span>Disk Usage</span>
                        <span><?= $disk_percent ?>%</span>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-primary" style="width: <?= $disk_percent ?>%"></div>
                    </div>
                    <p class="text-muted" style="font-size: 11px;"><?= $disk_used ?> MB of <?= $disk_limit ?> MB</p>
                </div>

                <div class="usage-item mt-3">
                    <div class="usage-label">
                        <span>Bandwidth</span>
                        <span><?= $bw_percent ?>%</span>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-success" style="width: <?= $bw_percent ?>%"></div>
                    </div>
                    <p class="text-muted" style="font-size: 11px;"><?= $bw_used ?> MB of <?= $bw_limit ?></p>
                </div>
            </div>
        </div>

        <div class="col-lg-9">
            <div class="card-rw p-4 mb-4">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <span class="status-badge mb-2 d-inline-block badge-<?= $row_order['status'] ?>">
                            <?= ucfirst($row_order['status']) ?>
                        </span>
                        <h3 class="fw-bold m-0"><?= htmlspecialchars($row_order['nama_paket']) ?></h3>
                        <p class="text-muted mb-3"><?= htmlspecialchars($row_order['domain']) ?></p>
                    </div>
                    <div class="text-end">
                        <a href="https://<?= $row_order['domain'] ?>" target="_blank" class="btn btn-rw-outline me-2">Visit Website</a>
                        <a href="<?= base_url('hosting/cpanel_sso.php?id=' . $id) ?>" target="_blank" class="btn btn-rw-primary">
        <i class="bi bi-gear-fill me-1"></i> Manage
    </a>
                    </div>
                </div>
            </div>

            <div class="card-rw">
                <div class="card-header">Quick Shortcuts</div>
                <div class="card-body">
                    <div class="row g-2">
                        <?php 
                        $shortcuts = [
                            ['Email Accounts', 'email_accounts.png', 'Email_Accounts'],
                            ['Forwarders', 'forwarders.png', 'Email_Forwarders'],
                            ['File Manager', 'file_manager.png', 'FileManager_Home'],
                            ['Backup', 'backup.png', 'Backups_Home'],
                            ['Subdomains', 'subdomains.png', 'Domains_SubDomains'],
                            ['MySQL Databases', 'mysql_databases.png', 'Database_MySQL'],
                            ['phpMyAdmin', 'php_my_admin.png', 'Database_phpMyAdmin'],
                            ['Cron Jobs', 'cron_jobs.png', 'Cron_Home'],
                        ];
                        foreach ($shortcuts as $sh): ?>
<div class="col-md-3 col-6">
    <a href="<?= base_url('hosting/cpanel_sso.php?id=' . $id . '&app=' . $sh[2]) ?>" target="_blank" class="cpanel-shortcut">
        <img src="<?= base_url('assets/' . $sh[1]) ?>" alt="<?= $sh[0] ?>">
        <div class="fw-medium"><?= $sh[0] ?></div>
    </a>
</div>
<?php endforeach; ?>
                    </div>
                </div>
            </div>

            <p class="text-center text-muted" style="font-size: 12px;">
                Information last updated: <strong><?= date('d/m/Y H:i') ?></strong>
            </p>
        </div>
    </div>
</div>

<?php include '../library/footer.php'; ?>