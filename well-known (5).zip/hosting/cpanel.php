<?php

session_start();
require_once '../config/database.php';
require_once '../core/WHMClient.php';

// =========================
// VALIDASI
// =========================
if (!isset($_SESSION['user_id'])) {
    die("❌ Belum login");
}

$id = (int) $_GET['id'];

$data = $conn->query("SELECT * FROM orders WHERE id = $id")->fetch_assoc();

if (!$data) die("❌ Data tidak ditemukan");

if ($data['user_id'] != $_SESSION['user_id']) {
    die("❌ Akses ditolak");
}

$username = $data['username'];

if (empty($username)) {
    die("❌ Username kosong");
}

// =========================
// WHM
// =========================
$whm = new WHMClient();

try {

    $session = $whm->createCpanelSession($username);

    // =========================
    // WAJIB ADA
    // =========================
    if (!isset($session['data']['url'])) {
        echo "<pre>";
        print_r($session);
        die("❌ URL tidak ditemukan");
    }

    // =========================
    // 🔥 LANGSUNG PAKAI URL ASLI
    // =========================
    $url = $session['data']['url'];

    // DEBUG (hapus nanti)
    // echo $url; die;

    header("Location: " . $url);
    exit;

} catch (Exception $e) {
    echo "❌ " . $e->getMessage();
}