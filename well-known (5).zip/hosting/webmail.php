<?php

require_once '../config/database.php';
require_once '../core/WHMClient.php';

session_start();

// =========================
// VALIDASI ID
// =========================
if (!isset($_GET['id'])) {
    die("ID tidak ditemukan");
}

$id = (int) $_GET['id'];

// =========================
// AMBIL DATA ORDER
// =========================
$query = $conn->query("
    SELECT * FROM orders 
    WHERE id='$id' 
    AND user_id='".$_SESSION['user_id']."'
");

$data = $query->fetch_assoc();

if (!$data) {
    die("Akses ditolak");
}

$username = $data['username'];

if (empty($username)) {
    die("Username hosting tidak ditemukan");
}

// =========================
// INIT WHM
// =========================
$whm = new WHMClient();

try {

    // =========================
    // CREATE SESSION WEBMAIL
    // =========================
    $session = $whm->createWebmailSession($username);

    if (!isset($session['data']['url'])) {
        throw new Exception("Gagal membuat session Webmail");
    }

    // =========================
    // REDIRECT KE WEBMAIL
    // =========================
    header("Location: " . $session['data']['url']);
    exit;

} catch (Exception $e) {

    echo "<h3>❌ Gagal login Webmail</h3>";
    echo $e->getMessage();
}