<?php

include '../config/database.php';
session_start();

// 1. Proteksi Halaman
if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// 2. Ambil data user untuk header
$query_user = mysqli_query($conn, "SELECT * FROM users WHERE id = '$user_id'");
$u = mysqli_fetch_assoc($query_user);

// 3. Data Produk (Bisa diambil dari database, atau hardcode seperti ini)
$products = [
    [
        'id' => 1,
        'name' => 'Starter Cloud',
        'price' => 15000,
        'discount' => 25000,
        'storage' => '1 GB SSD',
        'bandwidth' => 'Unlimited',
        'domain' => '1 Domain',
        'info' => 'Cocok untuk blog pribadi.',
        'badge' => '',
        'color' => 'primary'
    ],
    [
        'id' => 2,
        'name' => 'Business Pro',
        'price' => 45000,
        'discount' => 75000,
        'storage' => '10 GB NVMe',
        'bandwidth' => 'Unlimited',
        'domain' => '5 Domain',
        'info' => 'Terlaris untuk UMKM & Toko Online.',
        'badge' => 'MOST POPULAR',
        'color' => 'success'
    ],
    [
        'id' => 3,
        'name' => 'Enterprise SQL',
        'price' => 120000,
        'discount' => 200000,
        'storage' => 'Unlimited',
        'bandwidth' => 'Dedicated',
        'domain' => 'Unlimited',
        'info' => 'Performa maksimal untuk trafik tinggi.',
        'badge' => 'ULTIMATE',
        'color' => 'dark'
    ]
];

$page_title = "Pesan Hosting";
include '../library/header.php';
?>

<div class="main-content">
    <div class="text-center mb-5">
        <h2 class="fw-bold">Pilih Paket Hosting Terbaik</h2>
        <p class="text-muted">Infrastruktur cloud cepat, aman, dan handal untuk website Anda.</p>
    </div>

    <div class="row g-4 justify-content-center">
        <?php foreach ($products as $p): ?>
        <div class="col-lg-4 col-md-6">
            <div class="card h-100 border-0 shadow-sm rounded-4 position-relative overflow-hidden pricing-card">
                
                <?php if (!empty($p['badge'])): ?>
                <div class="pricing-badge bg-<?php echo $p['color']; ?>">
                    <?php echo $p['badge']; ?>
                </div>
                <?php endif; ?>

                <div class="card-body p-4 p-xl-5 text-center">
                    <h5 class="fw-bold text-uppercase text-muted small mb-4"><?php echo $p['name']; ?></h5>
                    
                    <div class="mb-4">
                        <span class="text-muted text-decoration-line-through small">Rp <?php echo number_format($p['discount'], 0, ',', '.'); ?></span>
                        <div class="d-flex justify-content-center align-items-baseline">
                            <span class="h4 fw-bold mb-0">Rp</span>
                            <span class="display-5 fw-extrabold mb-0"><?php echo number_format($p['price']/1000, 0); ?>k</span>
                            <span class="text-muted">/bln</span>
                        </div>
                    </div>

                    <p class="text-muted small mb-4"><?php echo $p['info']; ?></p>

                    <ul class="list-unstyled text-start mb-5">
                        <li class="mb-3 d-flex align-items-center">
                            <i class="bi bi-check-circle-fill text-success me-2"></i>
                            <span><strong><?php echo $p['storage']; ?></strong> Storage</span>
                        </li>
                        <li class="mb-3 d-flex align-items-center">
                            <i class="bi bi-check-circle-fill text-success me-2"></i>
                            <span><strong><?php echo $p['bandwidth']; ?></strong> Bandwidth</span>
                        </li>
                        <li class="mb-3 d-flex align-items-center">
                            <i class="bi bi-check-circle-fill text-success me-2"></i>
                            <span><?php echo $p['domain']; ?></span>
                        </li>
                        <li class="mb-3 d-flex align-items-center">
                            <i class="bi bi-check-circle-fill text-success me-2"></i>
                            <span>Free SSL & Backup</span>
                        </li>
                    </ul>

                    <a href="order.php?id=<?php echo $p['id']; ?>" 
                       class="btn btn-<?php echo $p['color']; ?> w-100 py-3 fw-bold rounded-pill shadow-sm mt-auto">
                        Pesan Sekarang
                    </a>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="mt-5 p-4 bg-white rounded-4 shadow-sm border-start border-primary border-4">
        <div class="d-flex align-items-center">
            <i class="bi bi-info-circle-fill fs-3 text-primary me-3"></i>
            <div>
                <h6 class="fw-bold mb-1">Butuh bantuan memilih?</h6>
                <p class="text-muted m-0 small">Hubungi tim teknis kami melalui WhatsApp jika Anda ragu paket mana yang sesuai dengan kebutuhan website Anda.</p>
            </div>
        </div>
    </div>
</div>

<style>
    .fw-extrabold { font-weight: 800; }
    
    .pricing-card {
        transition: all 0.3s ease;
        border: 2px solid transparent !important;
    }

    .pricing-card:hover {
        transform: translateY(-10px);
        border-color: #eef4ff !important;
        box-shadow: 0 20px 40px rgba(0,0,0,0.08) !important;
    }

    .pricing-badge {
        position: absolute;
        top: 20px;
        right: -35px;
        transform: rotate(45deg);
        width: 150px;
        text-align: center;
        font-size: 0.65rem;
        font-weight: 800;
        color: white;
        padding: 5px 0;
        letter-spacing: 1px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .btn-primary { background: #0d6efd; border: none; }
    .btn-success { background: #198754; border: none; }
    .btn-dark { background: #212529; border: none; }

    @media (max-width: 768px) {
        .display-5 { font-size: 2.5rem; }
    }
</style>

<?php include '../library/footer.php'; ?>