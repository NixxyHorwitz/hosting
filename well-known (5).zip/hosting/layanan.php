<?php
include '../config/database.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Cek Login
if (!isset($_SESSION['user_id'])) {
    header("Location: " . base_url('auth.php'));
    exit();
}

$user_id = $_SESSION['user_id'];

// 1. Ambil Data Hosting - PERBAIKAN: Ambil harga dari hp.harga_per_bulan
$sql_hosting = "SELECT o.*, hp.nama_paket, hp.harga_per_bulan 
                FROM orders o 
                LEFT JOIN hosting_plans hp ON o.hosting_plan_id = hp.id 
                WHERE o.user_id = '$user_id' 
                ORDER BY o.id DESC";
$query_hosting = mysqli_query($conn, $sql_hosting);

$page_title = "Layanan Saya";
include '../library/header.php';
?>

<style>
    .main-content { background-color: #f8f9fa; min-height: 100vh; padding-top: 20px; }
    .card-custom { border: none; border-radius: 15px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); overflow: hidden; }
    .table thead th { background-color: #f1f4f9; color: #475569; font-weight: 600; text-transform: uppercase; font-size: 0.75rem; letter-spacing: 0.025em; border: none; padding: 15px; }
    .table tbody td { padding: 18px 15px; vertical-align: middle; border-bottom: 1px solid #f1f5f9; }
    .status-badge { padding: 6px 12px; border-radius: 8px; font-size: 0.8rem; font-weight: 600; }
    .btn-action { border-radius: 10px; font-weight: 600; transition: all 0.2s; }
    .btn-action:hover { transform: translateY(-2px); }
    .service-icon { width: 40px; height: 40px; background: #e0e7ff; color: #4338ca; border-radius: 10px; display: flex; align-items: center; justify-content: center; margin-right: 15px; }
</style>

<div class="main-content">
    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
            <div>
                <h3 class="fw-extrabold text-dark m-0">Layanan & Domain</h3>
                <p class="text-muted small mb-0">Kelola semua paket hosting dan langganan Anda di sini.</p>
            </div>
            <a href="<?= base_url('hosting/') ?>" class="btn btn-primary rounded-pill px-4 shadow-sm">
                <i class="bi bi-plus-lg me-2"></i> Tambah Layanan
            </a>
        </div>

        <div class="card card-custom">
            <div class="card-header bg-white border-0 py-4 px-4">
                <div class="d-flex align-items-center">
                    <div class="service-icon">
                        <i class="bi bi-hdd-stack-fill fs-5"></i>
                    </div>
                    <h5 class="fw-bold mb-0 text-dark">Paket Hosting Aktif</h5>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>LAYANAN & DOMAIN</th>
                            <th>BIAYA / BULAN</th>
                            <th>STATUS</th>
                            <th class="text-center">KELOLA</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($query_hosting) > 0): ?>
                            <?php while($h = mysqli_fetch_assoc($query_hosting)): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div>
                                            <div class="fw-bold text-dark"><?= $h['nama_paket'] ?></div>
                                            <div class="text-muted small"><i class="bi bi-globe me-1"></i><?= $h['domain'] ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <span class="fw-bold text-dark">Rp <?= number_format($h['harga_per_bulan'], 0, ',', '.') ?></span>
                                </td>
                                <td>
                                    <?php if($h['status'] == 'pending'): ?>
                                        <span class="status-badge bg-warning-subtle text-warning">
                                            <i class="bi bi-clock-history me-1"></i> Menunggu Pembayaran
                                        </span>
                                    <?php elseif($h['status'] == 'active'): ?>
                                        <span class="status-badge bg-success-subtle text-success">
                                            <i class="bi bi-check-circle me-1"></i> Aktif
                                        </span>
                                    <?php else: ?>
                                        <span class="status-badge bg-danger-subtle text-danger">
                                            <?= ucfirst($h['status']) ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if($h['status'] == 'pending'): ?>
                                        <a href="<?= base_url('invoice?id='.$h['id'].'&type=hosting') ?>" class="btn btn-sm btn-primary btn-action px-3">
                                            Bayar Sekarang
                                        </a>
                                    <?php else: ?>
                                        <a href="<?= base_url('hosting/manage?id='.$h['id']) ?>" class="btn btn-sm btn-light btn-action border px-3">
                                            <i class="bi bi-gear-fill me-1"></i> Kelola
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center py-5">
                                    <img src="https://cdn-icons-png.flaticon.com/512/4076/4076432.png" width="80" class="mb-3 opacity-50">
                                    <p class="text-muted">Anda belum memiliki layanan aktif.</p>
                                    <a href="<?= base_url('hosting/order.php') ?>" class="btn btn-sm btn-outline-primary rounded-pill">Mulai Order</a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include '../library/footer.php'; ?>