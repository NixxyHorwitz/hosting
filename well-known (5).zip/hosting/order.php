<?php
include '../config/database.php';
include '../core/WHMClient.php';
session_start();

// 1. AMBIL KONFIGURASI DARI DATABASE SETTINGS
$query_settings = mysqli_query($conn, "SELECT * FROM settings LIMIT 1");
$settings = mysqli_fetch_assoc($query_settings);

$api_url    = "https://asteelass.icu/api/status.php";
$api_key    = $settings['payment_api_key'];
$secret_key = $settings['payment_secret_key'];

// 2. Ambil ID paket hosting & Nama Paket WHM
$plan_id = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : '';
$query_plan = mysqli_query($conn, "SELECT * FROM hosting_plans WHERE id = '$plan_id'");
$plan_data = mysqli_fetch_assoc($query_plan);

if (!$plan_data) { die("Paket tidak ditemukan."); }

$whm_package = $plan_data['whm_package_name']; 

$error_popup = "";

// 3. Logika Proses Checkout
if (isset($_POST['proses_checkout'])) {
    $durasi = (int)$_POST['durasi_hosting'];
    $harga_per_bulan = (int)$plan_data['harga_per_bulan'];
    $amount_to_request = $harga_per_bulan * $durasi;
    
    $domain = mysqli_real_escape_string($conn, $_POST['domain_tujuan_sendiri']);

    if (empty($domain)) {
        echo "<script>alert('Mohon masukkan nama domain Anda!'); window.history.back();</script>";
        exit();
    }

    // 4. Registrasi User Baru (Jika Belum Login)
    if (!isset($_SESSION['user_id'])) {
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $cek_email = mysqli_query($conn, "SELECT id FROM users WHERE email = '$email'");
        
        if (mysqli_num_rows($cek_email) > 0) {
            $error_popup = "email_terdaftar";
        } else {
            $nama = mysqli_real_escape_string($conn, $_POST['nama']);
            $password_hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $whatsapp = mysqli_real_escape_string($conn, $_POST['whatsapp']);
            $provinsi = mysqli_real_escape_string($conn, $_POST['provinsi']);
            $kota = mysqli_real_escape_string($conn, $_POST['kota']);

            $ins_user = "INSERT INTO users (nama, email, password, no_whatsapp, provinsi, kota, role) 
                         VALUES ('$nama', '$email', '$password_hash', '$whatsapp', '$provinsi', '$kota', 'client')";
            
            if (mysqli_query($conn, $ins_user)) {
                $_SESSION['user_id'] = mysqli_insert_id($conn);
                $_SESSION['user_nama'] = $nama;
            }
        }
    }

    // 5. Integrasi Payment Gateway & Simpan Order
    if (isset($_SESSION['user_id']) && $error_popup == "") {
        $current_user_id = $_SESSION['user_id'];
        $expiry_date = date('Y-m-d H:i:s', strtotime("+$durasi months"));

        // REQUEST KE PAYMENT GATEWAY
        $data_post = json_encode(['amount' => $amount_to_request]);
        
        $ch = curl_init($api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data_post);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'X-API-KEY: ' . $api_key,
            'X-SECRET-KEY: ' . $secret_key
        ]);

        $response = curl_exec($ch);
        $result = json_decode($response, true);
        curl_close($ch);

        if (isset($result['status']) && $result['status'] == true) {
            $reference_id  = $result['reference_id'];
            $final_amount  = $result['total_payment']; 
            // Ambil QR Code URL dari respon API
            $qr_url        = isset($result['qr_code_url']) ? $result['qr_code_url'] : '';

            mysqli_begin_transaction($conn);
            try {
                // INSERT TERMASUK whm_package_name DAN qr_code_url
                $sql_order = "INSERT INTO orders 
                (user_id, domain, hosting_plan_id, whm_package_name, total_harga, durasi, status, expiry_date, status_pembayaran, reference_id, qr_code_url) 
                VALUES 
                ('$current_user_id', '$domain', '$plan_id', '$whm_package', '$final_amount', '$durasi', 'pending', '$expiry_date', 'pending', '$reference_id', '$qr_url')";
                
                if (!mysqli_query($conn, $sql_order)) {
                    throw new Exception(mysqli_error($conn));
                }

                $order_id = mysqli_insert_id($conn);
                mysqli_commit($conn);
                
                header("Location: ../invoice.php?id=$order_id&msg=success");
                exit();
            } catch (Exception $e) {
                mysqli_rollback($conn);
                die("Kesalahan database: " . $e->getMessage());
            }
        } else {
            echo "<script>alert('Gagal menghubungi Payment Gateway. Cek API Key di Settings.'); window.history.back();</script>";
            exit();
        }
    }
}
include '../library/header.php';
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<style>
    :root { --primary-color: #4f46e5; --border-color: #e5e7eb; }
    body { background-color: #f3f4f6; font-family: 'Inter', sans-serif; }

    /* Desain Kartu Checkout */
    .checkout-card { border: none; border-radius: 16px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); background: white; margin-bottom: 1.5rem; overflow: hidden; }
    .card-header-custom { padding: 1.5rem 2rem; border-bottom: 1px solid var(--border-color); }
    .card-body-custom { padding: 2rem; }

    /* Opsi Durasi */
    .duration-option { border: 2px solid #e5e7eb; border-radius: 12px; padding: 1.2rem; cursor: pointer; transition: 0.2s; position: relative; }
    .duration-option:hover { border-color: #c7d2fe; }
    .duration-option.active { border-color: var(--primary-color); background: #eef2ff; }
    .duration-option .check-mark { position: absolute; top: 10px; right: 10px; color: var(--primary-color); display: none; }
    .duration-option.active .check-mark { display: block; }

    /* Ringkasan */
    .summary-card { background: #1e293b; color: white; border-radius: 16px; padding: 2rem; position: sticky; top: 2rem; }
    .btn-checkout { background: var(--primary-color); border: none; border-radius: 12px; padding: 14px; font-weight: 600; width: 100%; transition: 0.3s; color: white; }
    .btn-checkout:hover { background: #4338ca; transform: translateY(-2px); }
</style>

<div class="container py-5">
    <form action="" method="POST">
        <div class="row g-4">
            <div class="col-lg-8">
                <div class="checkout-card">
                    <div class="card-header-custom">
                        <h5 class="mb-0 fw-bold"><i class="bi bi-hdd-network me-2 text-primary"></i> Hubungkan Domain</h5>
                    </div>
                    <div class="card-body-custom">
                        <label class="form-label fw-bold small text-muted text-uppercase">Nama Domain Anda</label>
                        <div class="input-group input-group-lg">
                            <span class="input-group-text bg-light text-muted border-end-0"><i class="bi bi-globe"></i></span>
                            <input type="text" name="domain_tujuan_sendiri" class="form-control border-start-0" placeholder="contoh: websiteku.com" required>
                        </div>
                        <div class="mt-4 p-3 rounded-3 border bg-light">
                            <div class="d-flex">
                                <i class="bi bi-info-circle-fill text-primary me-2"></i>
                                <div>
                                    <small class="d-block fw-bold">Instruksi Nameserver:</small>
                                    <small class="text-muted">Arahkan domain Anda ke nameserver berikut agar bisa terhubung dengan hosting:</small>
                                    <div class="mt-2">
                                        <code class="bg-white px-2 py-1 border rounded">ns1.sobathosting.com</code>
                                        <code class="bg-white px-2 py-1 border rounded ms-1">ns2.sobathosting.com</code>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="checkout-card">
                    <div class="card-header-custom">
                        <h5 class="mb-0 fw-bold"><i class="bi bi-clock me-2 text-primary"></i> Pilih Durasi Berlangganan</h5>
                    </div>
                    <div class="card-body-custom">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <div class="duration-option active" onclick="updatePrice(1, this)">
                                    <i class="bi bi-check-circle-fill check-mark"></i>
                                    <h6 class="fw-bold mb-0">1 Bulan</h6>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="duration-option" onclick="updatePrice(6, this)">
                                    <i class="bi bi-check-circle-fill check-mark"></i>
                                    <h6 class="fw-bold mb-0">6 Bulan</h6>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="duration-option" onclick="updatePrice(12, this)">
                                    <i class="bi bi-check-circle-fill check-mark"></i>
                                    <h6 class="fw-bold mb-0">1 Tahun</h6>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="durasi_hosting" id="durasi_val" value="1">
                    </div>
                </div>

                <div class="checkout-card">
                    <div class="card-header-custom">
                        <h5 class="mb-0 fw-bold"><i class="bi bi-person-circle me-2 text-primary"></i> Detail Akun Pelanggan</h5>
                    </div>
                    <div class="card-body-custom">
                        <?php if (!isset($_SESSION['user_id'])): ?>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">NAMA LENGKAP</label>
                                    <input type="text" name="nama" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">EMAIL</label>
                                    <input type="email" name="email" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">WHATSAPP</label>
                                    <input type="number" name="whatsapp" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">PASSWORD</label>
                                    <input type="password" name="password" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">PROVINSI</label>
                                    <input type="text" name="provinsi" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">KOTA</label>
                                    <input type="text" name="kota" class="form-control" required>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="d-flex align-items-center p-3 bg-light rounded-3">
                                <i class="bi bi-check-circle-fill text-success fs-4 me-3"></i>
                                <div>
                                    <h6 class="mb-0 fw-bold">Anda sudah masuk sebagai <?= $_SESSION['user_nama']; ?></h6>
                                    <small class="text-muted">Pesanan ini akan otomatis dikaitkan dengan akun Anda.</small>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="summary-card">
                    <h5 class="fw-bold mb-4">Ringkasan Pesanan</h5>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="opacity-75">Paket Hosting</span>
                        <span class="fw-bold"><?= $plan_data['nama_paket']; ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="opacity-75">Durasi</span>
                        <span id="label_durasi">1 Bulan</span>
                    </div>
                    <hr class="my-4 opacity-10">
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="opacity-75">Total Bayar</span>
                        <h3 class="fw-bold mb-0" id="total_text">Rp <?= number_format($plan_data['harga_per_bulan'], 0, ',', '.'); ?></h3>
                    </div>
                    <button type="submit" name="proses_checkout" class="btn btn-checkout mt-4">
                        Konfirmasi & Bayar <i class="bi bi-arrow-right ms-2"></i>
                    </button>
                    <div class="mt-4 text-center">
                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Logo_QRIS.svg/1200px-Logo_QRIS.svg.png" height="30" style="filter: brightness(0) invert(1);">
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
    const pricePerMonth = <?= (int)$plan_data['harga_per_bulan']; ?>;
    function updatePrice(month, el) {
        document.getElementById('durasi_val').value = month;
        document.querySelectorAll('.duration-option').forEach(opt => opt.classList.remove('active'));
        el.classList.add('active');

        const total = pricePerMonth * month;
        document.getElementById('total_text').innerText = "Rp " + new Intl.NumberFormat('id-ID').format(total);
        document.getElementById('label_durasi').innerText = (month === 12) ? "1 Tahun" : month + " Bulan";
    }
</script>

<?php include '../library/footer.php'; ?>