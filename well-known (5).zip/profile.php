<?php
/**
 * SobatHosting - Profile Management
 * Author: Gemini AI
 */

include 'config/database.php';
session_start();

// 1. Proteksi Halaman (Middleware)
if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message_type = "";
$message_text = "";

// 2. Logika Update Profil & Password
if (isset($_POST['update_profile'])) {
    // Sanitasi Input Dasar
    $fields = ['nama', 'whatsapp', 'negara', 'provinsi', 'kota', 'kabupaten', 'kode_pos'];
    $data = [];
    foreach ($fields as $field) {
        $data[$field] = mysqli_real_escape_string($conn, $_POST[$field]);
    }

    $password_baru = $_POST['password_baru'];

    // Update Query Utama
    $sql_update = "UPDATE users SET 
                    nama='{$data['nama']}', 
                    no_whatsapp='{$data['whatsapp']}', 
                    negara='{$data['negara']}',
                    provinsi='{$data['provinsi']}', 
                    kota='{$data['kota']}', 
                    kabupaten='{$data['kabupaten']}', 
                    kode_pos='{$data['kode_pos']}' 
                  WHERE id='$user_id'";
    
    if (mysqli_query($conn, $sql_update)) {
        $_SESSION['user_nama'] = $data['nama']; 
        $message_type = "success";
        $message_text = "Data profil berhasil diperbarui!";
        
        // Logika Update Password (Hanya jika diisi)
        if (!empty($password_baru)) {
            if (strlen($password_baru) < 6) {
                $message_type = "warning";
                $message_text = "Profil diperbarui, namun password terlalu pendek (min. 6 karakter).";
            } else {
                $hash_baru = password_hash($password_baru, PASSWORD_DEFAULT);
                mysqli_query($conn, "UPDATE users SET password='$hash_baru' WHERE id='$user_id'");
                $message_text = "Profil dan password Anda telah diperbarui.";
            }
        }
    } else {
        $message_type = "error";
        $message_text = "Kesalahan sistem: Gagal memperbarui database.";
    }
}

// 3. Ambil Data Terbaru (Setelah update atau saat load halaman)
$query = mysqli_query($conn, "SELECT * FROM users WHERE id = '$user_id'");
$u = mysqli_fetch_assoc($query);

$page_title = "Profil Saya"; 
include 'library/header.php';
?>

<div class="main-content">
    <div class="row justify-content-center">
        <div class="col-xl-10">
            <header class="mb-4">
                <h3 class="fw-bold">Pengaturan Akun</h3>
                <p class="text-muted">Kelola informasi pribadi dan keamanan akun Anda.</p>
            </header>
            
            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="card card-profile border-0 shadow-sm p-4 text-center rounded-4">
                        <div class="avatar-circle mx-auto mb-3 shadow-sm">
                            <?php echo strtoupper(substr($u['nama'], 0, 1)); ?>
                        </div>
                        <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($u['nama'], ENT_QUOTES); ?></h5>
                        <p class="text-muted small mb-3"><?php echo $u['email']; ?></p>
                        
                        <div class="d-inline-block badge bg-primary-subtle text-primary border border-primary-subtle px-3 py-2 rounded-pill mb-4">
                            <i class="bi bi-shield-check me-1"></i> Role: <?php echo strtoupper($u['role']); ?>
                        </div>
                        
                        <hr class="opacity-50">
                        
                        <div class="text-start mt-4">
                            <label class="small text-muted d-block mb-1">Domisili Utama:</label>
                            <p class="fw-semibold small m-0"><i class="bi bi-geo-alt-fill text-danger me-2"></i> <?php echo !empty($u['negara']) ? $u['negara'] : '-'; ?></p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-8">
                    <div class="card card-profile border-0 shadow-sm p-4 p-md-5 rounded-4">
                        <form action="" method="POST">
                            <div class="d-flex align-items-center mb-4">
                                <i class="bi bi-person-lines-fill fs-4 text-primary me-3"></i>
                                <h6 class="fw-bold m-0 text-uppercase tracking-wider">Informasi Pribadi</h6>
                            </div>

                            <div class="row g-3 mb-5">
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">NAMA LENGKAP</label>
                                    <input type="text" name="nama" class="form-control" value="<?php echo htmlspecialchars($u['nama'], ENT_QUOTES); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">WHATSAPP</label>
                                    <input type="text" name="whatsapp" class="form-control" value="<?php echo $u['no_whatsapp']; ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">NEGARA</label>
                                    <input type="text" name="negara" class="form-control" value="<?php echo htmlspecialchars($u['negara'], ENT_QUOTES); ?>">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label small fw-bold">PROVINSI</label>
                                    <input type="text" name="provinsi" class="form-control" value="<?php echo htmlspecialchars($u['provinsi'], ENT_QUOTES); ?>">
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label small fw-bold">KOTA</label>
                                    <input type="text" name="kota" class="form-control" value="<?php echo htmlspecialchars($u['kota'], ENT_QUOTES); ?>">
                                </div>
                                <div class="col-md-5">
                                    <label class="form-label small fw-bold">KECAMATAN / KAB.</label>
                                    <input type="text" name="kabupaten" class="form-control" value="<?php echo htmlspecialchars($u['kabupaten'], ENT_QUOTES); ?>">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold">KODE POS</label>
                                    <input type="text" name="kode_pos" class="form-control" value="<?php echo $u['kode_pos']; ?>">
                                </div>
                            </div>

                            <div class="d-flex align-items-center mb-4">
                                <i class="bi bi-key-fill fs-4 text-danger me-3"></i>
                                <h6 class="fw-bold m-0 text-uppercase tracking-wider">Keamanan Akun</h6>
                            </div>

                            <div class="row g-3">
                                <div class="col-md-8">
                                    <label class="form-label small fw-bold">GANTI PASSWORD</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-white border-end-0"><i class="bi bi-lock"></i></span>
                                        <input type="password" name="password_baru" id="passInput" class="form-control border-start-0" placeholder="Biarkan kosong jika tidak diubah">
                                        <button class="btn btn-outline-secondary border-start-0 bg-white" type="button" onclick="togglePass()">
                                            <i class="bi bi-eye" id="toggleIcon"></i>
                                        </button>
                                    </div>
                                    <div class="form-text text-muted">Gunakan minimal 6 karakter kombinasi huruf dan angka.</div>
                                </div>
                            </div>

                            <div class="mt-5 pt-3 border-top">
                                <button type="submit" name="update_profile" class="btn btn-primary px-5 py-3 fw-bold rounded-pill shadow-sm">
                                    <i class="bi bi-save me-2"></i> SIMPAN PERUBAHAN
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .avatar-circle {
        width: 80px; height: 80px; background: #eef4ff; color: #0d6efd;
        display: flex; align-items: center; justify-content: center;
        font-size: 2.2rem; font-weight: 800; border-radius: 50%;
    }
    .tracking-wider { letter-spacing: 1px; }
    .form-control { border-radius: 10px; padding: 12px 15px; border: 1px solid #dee2e6; }
    .form-control:focus { box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1); border-color: #0d6efd; }
    .card-profile { background: #fff; }
</style>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    // Fungsi Toggle Visibility Password
    function togglePass() {
        const p = document.getElementById('passInput');
        const i = document.getElementById('toggleIcon');
        p.type = p.type === 'password' ? 'text' : 'password';
        i.classList.toggle('bi-eye'); 
        i.classList.toggle('bi-eye-slash');
    }

    // SweetAlert Handler
    <?php if($message_type): ?>
    Swal.fire({
        icon: '<?php echo $message_type; ?>',
        title: '<?php echo ($message_type == "success") ? "Berhasil!" : "Pemberitahuan"; ?>',
        text: '<?php echo $message_text; ?>',
        confirmButtonColor: '#0d6efd',
        borderRadius: '15px'
    });
    <?php endif; ?>
</script>
</body>
</html>