<?php
// 1. Matikan output buffering agar tidak ada spasi yang bocor
ob_start();

// 2. Pengaturan Session yang Ketat & Universal
ini_set('session.cookie_path', '/'); 
ini_set('session.gc_maxlifetime', 3600);
session_set_cookie_params(3600, '/', '', true, true);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// 3. Fungsi Base URL
function base_url($path = '') {
    $base = "https://testing.hbklegacy.icu/";
    return $base . ltrim($path, '/');
}

// 4. Koneksi Database
$host = "localhost";
$user = "user115_hosting";
$pass = "user115_hosting";
$db   = "user115_hosting";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// 5. Penarikan Data Settings Otomatis
$query_settings = mysqli_query($conn, "SELECT * FROM settings WHERE id = 1");
$set = mysqli_fetch_assoc($query_settings);

if ($set) {
    // =========================
    // WHM CONFIG (Dinamis dari DB)
    // =========================
    define('WHM_HOST',     $set['whm_host']);
    define('WHM_USERNAME', $set['whm_username']);
    define('WHM_TOKEN',    $set['whm_token']);

    // =========================
    // SITE INFO (Dinamis dari DB)
    // =========================
    define('SITE_NAME', $set['site_name']);
    define('SITE_TITLE', $set['site_title']);
    define('SITE_DESC', $set['site_description']);
}

// =========================
// DEFAULT NAMESERVER (Static)
// =========================
    define('NS1', $set['ns1']);
    define('NS2', $set['ns2']);
    define('NS3', $set['ns3'] ?? ''); 
    define('NS4', $set['ns4'] ?? '');