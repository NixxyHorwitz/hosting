<?php
session_start();
require_once '../config/database.php';

$error = '';

if (!isset($_SESSION['admin_id'])) {
    header("Location: login");
    exit;
}

// Fungsi bantu untuk hitung total
function countData($conn, $query) {
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_array($result);
    return $row[0] ?? 0;
}

// Statistik
$total_users    = countData($conn, "SELECT COUNT(*) FROM users");
$active_hosting  = countData($conn, "SELECT COUNT(*) FROM orders WHERE status = 'active'");
$active_domains  = countData($conn, "SELECT COUNT(*) FROM domain_orders WHERE status = 'active'");
$revenue         = countData($conn, "SELECT SUM(total_harga) FROM orders WHERE status_pembayaran = 'success'");

// Ambil data pesanan terbaru
$recent_orders = mysqli_query($conn, "SELECT * FROM orders ORDER BY created_at DESC LIMIT 5");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Domain & Hosting</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-zinc-950 text-zinc-200 font-sans">

    <div class="flex min-h-screen">
        <aside class="w-64 bg-zinc-900 border-r border-zinc-800 flex flex-col">
            <div class="p-6">
                <h1 class="text-xl font-bold text-white flex items-center gap-2">
                    <i class="fas fa-server text-blue-500"></i> CloudAdmin
                </h1>
            </div>
            
            <nav class="flex-1 px-4 space-y-2">
                <a href="<?= base_url('admin/dashboard') ?>" class="flex items-center gap-3 px-4 py-3 bg-blue-600 text-white rounded-lg transition">
                    <i class="fas fa-chart-line"></i> Dashboard
                </a>
                <a href="<?= base_url('admin/hosting_plans') ?>" class="flex items-center gap-3 px-4 py-3 hover:bg-zinc-800 rounded-lg transition">
                    <i class="fas fa-hdd"></i> Hosting Plans
                </a>
                <a href="<?= base_url('admin/domain_plans') ?>" class="flex items-center gap-3 px-4 py-3 hover:bg-zinc-800 rounded-lg transition">
                    <i class="fas fa-globe"></i> Domain Prices
                </a>
                <a href="<?= base_url('admin/orders') ?>" class="flex items-center gap-3 px-4 py-3 hover:bg-zinc-800 rounded-lg transition">
                    <i class="fas fa-shopping-cart"></i> Orders
                </a>
                <a href="<?= base_url('admin/users') ?>" class="flex items-center gap-3 px-4 py-3 hover:bg-zinc-800 rounded-lg transition">
                    <i class="fas fa-users"></i> Customers
                </a>
                <a href="<?= base_url('admin/website') ?>" class="flex items-center gap-3 px-4 py-3 hover:bg-zinc-800 rounded-lg transition">
                    <i class="fas fa-users"></i> Website
                </a>
            </nav>

            <div class="p-4 border-t border-zinc-800">
                <a href="<?= base_url('admin/logout') ?>" class="flex items-center gap-3 px-4 py-3 text-red-400 hover:bg-red-500/10 rounded-lg transition">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </aside>

        <main class="flex-1 p-8 overflow-y-auto">
            <header class="flex justify-between items-center mb-10">
                <div>
                    <h2 class="text-2xl font-bold text-white">Selamat Datang, <?= $_SESSION['username'] ?>!</h2>
                    <p class="text-zinc-500">Berikut adalah ringkasan bisnis Anda hari ini.</p>
                </div>
                <div class="flex items-center gap-4">
                    <div class="bg-zinc-900 p-2 px-4 rounded-full border border-zinc-800">
                        <span class="text-sm text-zinc-400"><i class="fas fa-calendar-alt mr-2"></i> <?= date('d M Y') ?></span>
                    </div>
                </div>
            </header>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
                <div class="bg-zinc-900 p-6 rounded-2xl border border-zinc-800">
                    <p class="text-zinc-500 text-sm mb-2">Total Pendapatan</p>
                    <h3 class="text-2xl font-bold text-green-400">Rp <?= number_format($revenue ?? 0, 0, ',', '.') ?></h3>
                </div>
                <div class="bg-zinc-900 p-6 rounded-2xl border border-zinc-800">
                    <p class="text-zinc-500 text-sm mb-2">Total Pelanggan</p>
                    <h3 class="text-2xl font-bold text-white"><?= $total_users ?></h3>
                </div>
                <div class="bg-zinc-900 p-6 rounded-2xl border border-zinc-800">
                    <p class="text-zinc-500 text-sm mb-2">Hosting Aktif</p>
                    <h3 class="text-2xl font-bold text-blue-400"><?= $active_hosting ?></h3>
                </div>
                <div class="bg-zinc-900 p-6 rounded-2xl border border-zinc-800">
                    <p class="text-zinc-500 text-sm mb-2">Domain Terdaftar</p>
                    <h3 class="text-2xl font-bold text-purple-400"><?= $active_domains ?></h3>
                </div>
            </div>

            <div class="bg-zinc-900 rounded-2xl border border-zinc-800 overflow-hidden">
                <div class="p-6 border-b border-zinc-800 flex justify-between items-center">
                    <h3 class="text-lg font-bold text-white">Pesanan Hosting Terbaru</h3>
                    <button class="text-sm text-blue-500 hover:underline">Lihat Semua</button>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left text-sm">
                        <thead class="bg-zinc-800/50 text-zinc-400 uppercase text-xs">
                            <tr>
                                <th class="px-6 py-4">Domain</th>
                                <th class="px-6 py-4">Username</th>
                                <th class="px-6 py-4">Status</th>
                                <th class="px-6 py-4">Pembayaran</th>
                                <th class="px-6 py-4">Tanggal</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-zinc-800">
                            <?php foreach ($recent_hosting as $order): ?>
                            <tr class="hover:bg-zinc-800/30 transition">
                                <td class="px-6 py-4 font-medium text-white"><?= $order['domain'] ?></td>
                                <td class="px-6 py-4"><?= $order['username'] ?></td>
                                <td class="px-6 py-4">
                                    <span class="px-2 py-1 rounded-md text-xs <?= $order['status'] == 'active' ? 'bg-green-500/10 text-green-500' : 'bg-yellow-500/10 text-yellow-500' ?>">
                                        <?= strtoupper($order['status']) ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="text-xs italic text-zinc-400"><?= $order['status_pembayaran'] ?></span>
                                </td>
                                <td class="px-6 py-4 text-zinc-500"><?= date('d/m/Y', strtotime($order['created_at'])) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

</body>
</html>