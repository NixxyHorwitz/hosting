<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../config/database.php';

// Proteksi Admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php"); 
    exit();
}

// Logika Hapus Produk
if (isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete']);
    mysqli_query($conn, "DELETE FROM hosting_plans WHERE id = '$id'");
    header("Location: hosting_plans.php?status=deleted");
    exit();
}

// Ambil Data Produk
$query = mysqli_query($conn, "SELECT * FROM hosting_plans ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Hosting - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        body { background-color: #09090b; color: #e4e4e7; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; background: #18181b; min-height: 100vh; border-right: 1px solid #27272a; position: fixed; }
        .main-content { margin-left: 260px; padding: 40px; }
        .card-custom { background: #18181b; border: 1px solid #27272a; border-radius: 16px; overflow: hidden; }
        .table { color: #e4e4e7; border-color: #27272a; }
        .table thead { background: #27272a; color: #a1a1aa; font-size: 0.8rem; text-transform: uppercase; }
        .form-control, .form-select { background: #27272a; border: 1px solid #3f3f46; color: #fff; }
        .form-control:focus { background: #27272a; color: #fff; border-color: #3b82f6; box-shadow: none; }
        .btn-add { background: #3b82f6; border: none; border-radius: 10px; font-weight: 600; transition: 0.3s; }
        .btn-add:hover { background: #2563eb; transform: translateY(-2px); }
        .nav-link { color: #a1a1aa; padding: 12px 20px; border-radius: 10px; margin: 5px 15px; transition: 0.3s; }
        .nav-link:hover, .nav-link.active { background: #27272a; color: #fff; }
        .badge-info { background: rgba(59, 130, 246, 0.1); color: #3b82f6; border: 1px solid rgba(59, 130, 246, 0.2); }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="p-4 mb-4">
        <h5 class="fw-bold text-white"><i class="bi bi-cpu-fill text-primary me-2"></i> CLOUD ADMIN</h5>
    </div>
    <nav class="nav flex-column">
        <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a class="nav-link active" href="hosting_plans.php"><i class="bi bi-hdd-network me-2"></i> Hosting Plans</a>
        <a class="nav-link" href="#"><i class="bi bi-globe me-2"></i> Domain Prices</a>
        <a class="nav-link" href="#"><i class="bi bi-cart me-2"></i> Orders</a>
        <hr class="mx-3 border-secondary">
        <a class="nav-link text-danger" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold text-white">Kelola Paket Hosting</h3>
            <p class="text-muted small">Atur paket, harga, dan limitasi resource hosting Anda.</p>
        </div>
        <button class="btn btn-primary btn-add px-4" data-bs-toggle="modal" data-bs-target="#addModal">
            <i class="bi bi-plus-lg me-2"></i> Tambah Paket
        </button>
    </div>

    <div class="card card-custom">
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead>
                    <tr>
                        <th class="px-4 py-3">Nama Paket</th>
                        <th>Disk Limit</th>
                        <th>Bandwidth</th>
                        <th>WHM Name</th>
                        <th>Harga /Bulan</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($query)): ?>
                    <tr>
                        <td class="px-4">
                            <span class="fw-bold text-white"><?php echo $row['nama_paket']; ?></span>
                        </td>
                        <td><span class="badge badge-info"><?php echo $row['disk_limit']; ?></span></td>
                        <td><?php echo $row['bandwidth_limit']; ?></td>
                        <td class="text-muted small"><?php echo $row['whm_package_name']; ?></td>
                        <td class="fw-bold text-success">Rp <?php echo number_format($row['harga_per_bulandecimal'], 0, ',', '.'); ?></td>
                        <td class="text-center">
                            <button class="btn btn-sm btn-outline-light border-secondary me-1" title="Edit"><i class="bi bi-pencil"></i></button>
                            <button class="btn btn-sm btn-outline-danger border-danger-subtle" onclick="confirmDelete(<?php echo $row['id']; ?>)" title="Hapus"><i class="bi bi-trash"></i></button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="addModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-zinc-900 border-secondary" style="background: #18181b; border: 1px solid #27272a;">
            <div class="modal-header border-secondary">
                <h5 class="modal-title text-white">Tambah Paket Hosting Baru</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="process_hosting.php" method="POST">
                <div class="modal-body text-white">
                    <div class="mb-3">
                        <label class="form-label small">Nama Paket</label>
                        <input type="text" name="nama_paket" class="form-control" placeholder="Contoh: Paket Hemat" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label small">Disk Limit (MB/GB)</label>
                            <input type="text" name="disk_limit" class="form-control" placeholder="10 GB" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label small">Bandwidth</label>
                            <input type="text" name="bandwidth_limit" class="form-control" placeholder="Unlimited" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small">WHM Package Name (Sesuai di WHM)</label>
                        <input type="text" name="whm_name" class="form-control" placeholder="sh_hemat" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small">Harga Per Bulan</label>
                        <div class="input-group">
                            <span class="input-group-text bg-dark border-secondary text-white">Rp</span>
                            <input type="number" name="harga" class="form-control" placeholder="50000" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-dark" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="add_plan" class="btn btn-primary px-4">Simpan Paket</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmDelete(id) {
        Swal.fire({
            title: 'Hapus Paket?',
            text: "Data paket hosting ini akan dihapus permanen!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ef4444',
            cancelButtonColor: '#27272a',
            confirmButtonText: 'Ya, Hapus!',
            background: '#18181b',
            color: '#fff'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'hosting_plans.php?delete=' + id;
            }
        })
    }

    // Notifikasi jika berhasil
    <?php if(isset($_GET['status']) && $_GET['status'] == 'deleted'): ?>
        Swal.fire({
            icon: 'success',
            title: 'Terhapus!',
            text: 'Paket hosting telah berhasil dihapus.',
            timer: 2000,
            showConfirmButton: false,
            background: '#18181b',
            color: '#fff'
        });
    <?php endif; ?>
</script>
</body>
</html>