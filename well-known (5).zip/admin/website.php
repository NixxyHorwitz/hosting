<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../config/database.php';

// Proteksi Admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php"); 
    exit();
}

// Logika Update Settings
if (isset($_POST['update_settings'])) {
    $site_name = mysqli_real_escape_string($conn, $_POST['site_name']);
    $site_title = mysqli_real_escape_string($conn, $_POST['site_title']);
    $site_desc = mysqli_real_escape_string($conn, $_POST['site_description']);
    $whm_host = mysqli_real_escape_string($conn, $_POST['whm_host']);
    $whm_user = mysqli_real_escape_string($conn, $_POST['whm_username']);
    $whm_token = mysqli_real_escape_string($conn, $_POST['whm_token']);
    $api_key = mysqli_real_escape_string($conn, $_POST['api_key']);
    $secret_key = mysqli_real_escape_string($conn, $_POST['secret_key']);
    
    // Ambil input Nameserver
    $ns1 = mysqli_real_escape_string($conn, $_POST['ns1']);
    $ns2 = mysqli_real_escape_string($conn, $_POST['ns2']);
    $ns3 = mysqli_real_escape_string($conn, $_POST['ns3']);
    $ns4 = mysqli_real_escape_string($conn, $_POST['ns4']);

    $update = "UPDATE settings SET 
               site_name='$site_name', 
               site_title='$site_title', 
               site_description='$site_desc',
               whm_host='$whm_host',
               whm_username='$whm_user',
               whm_token='$whm_token',
               payment_api_key='$api_key',
               payment_secret_key='$secret_key',
               ns1='$ns1',
               ns2='$ns2',
               ns3='$ns3',
               ns4='$ns4'
               WHERE id=1";

    if (mysqli_query($conn, $update)) {
        header("Location: <?= base_url('admin/website') ?>?status=success");
    } else {
        header("Location: <?= base_url('admin/website') ?>?status=error");
    }
    exit();
}

// Ambil data settings
$query = mysqli_query($conn, "SELECT * FROM settings WHERE id = 1");
$set = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfigurasi Sistem - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        body { background-color: #09090b; color: #e4e4e7; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; background: #18181b; min-height: 100vh; border-right: 1px solid #27272a; position: fixed; }
        .main-content { margin-left: 260px; padding: 40px; }
        .card-settings { background: #18181b; border: 1px solid #27272a; border-radius: 16px; }
        .nav-pills .nav-link { color: #a1a1aa; border-radius: 10px; padding: 12px 20px; margin-bottom: 5px; transition: 0.3s; }
        .nav-pills .nav-link.active { background: #3b82f6; color: #fff; }
        .form-control { background: #09090b; border: 1px solid #27272a; color: #fff; border-radius: 10px; padding: 12px; }
        .form-control:focus { background: #09090b; border-color: #3b82f6; color: #fff; box-shadow: none; }
        label { font-weight: 600; color: #a1a1aa; font-size: 0.85rem; margin-bottom: 8px; }
        .btn-save { background: #3b82f6; border: none; padding: 12px 30px; border-radius: 10px; font-weight: 700; }
        .section-divider { border-top: 1px solid #27272a; margin: 30px 0; padding-top: 20px; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="p-4 mb-4">
        <h5 class="fw-bold text-white"><i class="bi bi-gear-fill text-primary me-2"></i> SETTINGS</h5>
    </div>
    <nav class="nav flex-column px-3">
        <a class="nav-link text-light mb-2" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a class="nav-link active mb-2" href="<?= base_url('admin/website') ?>"><i class="bi bi-sliders me-2"></i> System Config</a>
        <hr class="border-secondary">
        <a class="nav-link text-danger" href="<?= base_url('admin/logout') ?>"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="mb-4">
        <h3 class="fw-bold text-white">Konfigurasi Sistem</h3>
        <p class="text-muted small">Kelola identitas website, kredensial API, dan nameserver secara terpusat.</p>
    </div>

    <form action="" method="POST">
        <div class="row">
            <div class="col-md-3">
                <div class="nav flex-column nav-pills me-3" id="v-pills-tab" role="tablist">
                    <button class="nav-link active text-start" data-bs-toggle="pill" data-bs-target="#tab-general" type="button"><i class="bi bi-globe2 me-2"></i> Umum</button>
                    <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tab-whm" type="button"><i class="bi bi-server me-2"></i> Server & NS</button>
                    <button class="nav-link text-start" data-bs-toggle="pill" data-bs-target="#tab-payment" type="button"><i class="bi bi-credit-card me-2"></i> Pembayaran</button>
                </div>
            </div>
            
            <div class="col-md-9">
                <div class="card card-settings p-4 shadow-sm">
                    <div class="tab-content" id="v-pills-tabContent">
                        
                        <div class="tab-pane fade show active" id="tab-general">
                            <h5 class="text-white mb-4">Informasi Website</h5>
                            <div class="mb-3">
                                <label>Nama Website</label>
                                <input type="text" name="site_name" class="form-control" value="<?php echo $set['site_name']; ?>">
                            </div>
                            <div class="mb-3">
                                <label>Tagline / Title</label>
                                <input type="text" name="site_title" class="form-control" value="<?php echo $set['site_title']; ?>">
                            </div>
                            <div class="mb-3">
                                <label>Deskripsi SEO</label>
                                <textarea name="site_description" class="form-control" rows="3"><?php echo $set['site_description']; ?></textarea>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="tab-whm">
                            <h5 class="text-white mb-4">Koneksi WHM Server</h5>
                            <div class="mb-3">
                                <label>WHM Host (URL/IP)</label>
                                <input type="text" name="whm_host" class="form-control" placeholder="https://ip-server:2087" value="<?php echo $set['whm_host']; ?>">
                            </div>
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label>WHM Username</label>
                                    <input type="text" name="whm_username" class="form-control" value="<?php echo $set['whm_username']; ?>">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label>WHM API Token</label>
                                <textarea name="whm_token" class="form-control" rows="3"><?php echo $set['whm_token']; ?></textarea>
                            </div>

                            <div class="section-divider">
                                <h5 class="text-white mb-4">Default Nameservers</h5>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label>Nameserver 1</label>
                                        <input type="text" name="ns1" class="form-control" value="<?php echo $set['ns1']; ?>" placeholder="ns1.example.com">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label>Nameserver 2</label>
                                        <input type="text" name="ns2" class="form-control" value="<?php echo $set['ns2']; ?>" placeholder="ns2.example.com">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label>Nameserver 3</label>
                                        <input type="text" name="ns3" class="form-control" value="<?php echo $set['ns3']; ?>" placeholder="ns3.example.com">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label>Nameserver 4</label>
                                        <input type="text" name="ns4" class="form-control" value="<?php echo $set['ns4']; ?>" placeholder="ns4.example.com">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="tab-payment">
                            <h5 class="text-white mb-4">Payment Gateway</h5>
                            <div class="mb-3">
                                <label>API Client Key</label>
                                <input type="text" name="api_key" class="form-control" value="<?php echo $set['payment_api_key']; ?>">
                            </div>
                            <div class="mb-3">
                                <label>Secret Key / Server Key</label>
                                <input type="password" name="secret_key" class="form-control" value="<?php echo $set['payment_secret_key']; ?>">
                            </div>
                        </div>

                    </div>
                    
                    <div class="mt-4 pt-4 border-top border-secondary text-end">
                        <button type="submit" name="website" class="btn btn-primary btn-save shadow-sm">
                            <i class="bi bi-check-circle me-2"></i> SIMPAN PERUBAHAN
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    <?php if(isset($_GET['status']) && $_GET['status'] == 'success'): ?>
        Swal.fire({
            icon: 'success',
            title: 'Tersimpan!',
            text: 'Konfigurasi telah berhasil diperbarui.',
            background: '#18181b',
            color: '#fff',
            confirmButtonColor: '#3b82f6'
        });
    <?php elseif(isset($_GET['status']) && $_GET['status'] == 'error'): ?>
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: 'Terjadi kesalahan saat menyimpan data.',
            background: '#18181b',
            color: '#fff'
        });
    <?php endif; ?>
</script>
</body>
</html>