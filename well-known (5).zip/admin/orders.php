<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../config/database.php';
require_once '../core/WHMClient.php'; 

// Proteksi Admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php"); 
    exit();
}

$whm = new WHMClient();

// Logika Update Status dengan Integrasi WHM
if (isset($_GET['update_status']) && isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $new_status = mysqli_real_escape_string($conn, $_GET['update_status']);
    
    // Ambil data username cPanel dari order ini
    $check_order = mysqli_query($conn, "SELECT username FROM orders WHERE id = '$id'");
    $order_data = mysqli_fetch_assoc($check_order);
    $cp_user = $order_data['username'];

    try {
        if ($new_status == 'active') {
            // Jika sebelumnya suspend, jalankan unsuspend di WHM
            $whm->unsuspendAccount($cp_user);
        } 
        elseif ($new_status == 'suspended') {
            // Jalankan perintah suspend di WHM
            $whm->suspendAccount($cp_user, "Pelanggaran atau Belum Bayar");
        }

        // Jika perintah WHM berhasil (tidak lempar Exception), baru update Database
        mysqli_query($conn, "UPDATE orders SET status = '$new_status' WHERE id = '$id'");
        header("Location: orders?res=success&msg=" . urlencode("Status $cp_user berhasil diubah ke $new_status"));
        
    } catch (Exception $e) {
        // Jika WHM error, tangkap pesan errornya
        header("Location: orders?res=error&msg=" . urlencode($e->getMessage()));
    }
    exit();
}

// Ambil Data Order dengan Join ke tabel Users dan Hosting Plans (jika ada)
$query = mysqli_query($conn, "SELECT orders.*, users.nama as nama_user, hosting_plans.nama_paket 
                              FROM orders 
                              LEFT JOIN users ON orders.user_id = users.id 
                              LEFT JOIN hosting_plans ON orders.hosting_plan_id = hosting_plans.id 
                              ORDER BY orders.created_at DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pesanan - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        body { background-color: #09090b; color: #e4e4e7; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; background: #18181b; min-height: 100vh; border-right: 1px solid #27272a; position: fixed; }
        .main-content { margin-left: 260px; padding: 40px; }
        .card-custom { background: #18181b; border: 1px solid #27272a; border-radius: 16px; overflow: hidden; }
        .table { color: #e4e4e7; border-color: #27272a; font-size: 0.9rem; }
        .table thead { background: #27272a; color: #a1a1aa; font-size: 0.75rem; text-transform: uppercase; }
        
        .nav-link { color: #a1a1aa; padding: 12px 20px; border-radius: 10px; margin: 5px 15px; transition: 0.3s; }
        .nav-link:hover, .nav-link.active { background: #27272a; color: #fff; }

        /* Status Colors */
        .badge-pending { background: rgba(245, 158, 11, 0.1); color: #f59e0b; border: 1px solid rgba(245, 158, 11, 0.2); }
        .badge-active { background: rgba(16, 185, 129, 0.1); color: #10b981; border: 1px solid rgba(16, 185, 129, 0.2); }
        .badge-suspended { background: rgba(239, 68, 68, 0.1); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.2); }
        
        .text-price { color: #10b981; font-weight: 700; }
        .acc-info { font-size: 0.75rem; background: #27272a; padding: 5px 10px; border-radius: 5px; color: #a1a1aa; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="p-4 mb-4">
        <h5 class="fw-bold text-white"><i class="bi bi-cart-check-fill text-primary me-2"></i> CLOUD ADMIN</h5>
    </div>
    <nav class="nav flex-column">
        <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a class="nav-link" href="hosting_plans.php"><i class="bi bi-hdd-network me-2"></i> Hosting Plans</a>
        <a class="nav-link" href="domain_plans.php"><i class="bi bi-globe me-2"></i> Domain Prices</a>
        <a class="nav-link active" href="orders.php"><i class="bi bi-cart me-2"></i> Orders</a>
        <hr class="mx-3 border-secondary">
        <a class="nav-link text-danger" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="mb-4">
        <h3 class="fw-bold text-white">Manajemen Pesanan</h3>
        <p class="text-muted small">Pantau pembayaran dan aktivasi akun hosting pelanggan.</p>
    </div>

    <div class="card card-custom">
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead>
                    <tr>
                        <th class="px-4 py-3">Order ID</th>
                        <th>Pelanggan / Domain</th>
                        <th>Paket / Durasi</th>
                        <th>Total Harga</th>
                        <th>Status Layanan</th>
                        <th>Pembayaran</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = mysqli_fetch_assoc($query)): ?>
                    <tr>
                        <td class="px-4 text-muted">#<?php echo $row['id']; ?></td>
                        <td>
                            <div class="fw-bold text-white"><?php echo $row['nama_user'] ?? 'Guest'; ?></div>
                            <div class="text-primary small"><i class="bi bi-link-45deg"></i> <?php echo $row['domain']; ?></div>
                        </td>
                        <td>
                            <div><?php echo $row['nama_paket'] ?? 'N/A'; ?></div>
                            <div class="text-muted small"><?php echo $row['durasi']; ?> Bulan</div>
                        </td>
                        <td><span class="text-price">Rp <?php echo number_format($row['total_harga'], 0, ',', '.'); ?></span></td>
                        <td>
                            <span class="badge badge-<?php echo $row['status']; ?>">
                                <?php echo strtoupper($row['status']); ?>
                            </span>
                        </td>
                        <td>
                            <?php if($row['status_pembayaran'] == 'success'): ?>
                                <span class="text-success small"><i class="bi bi-check-circle-fill"></i> Lunas</span>
                            <?php else: ?>
                                <span class="text-warning small"><i class="bi bi-clock-history"></i> <?php echo ucfirst($row['status_pembayaran']); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <div class="dropdown">
                                <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    Kelola
                                </button>
                                <ul class="dropdown-menu dropdown-menu-dark">
                                    <li><a class="dropdown-item" href="?update_status=active&id=<?php echo $row['id']; ?>"><i class="bi bi-play-circle me-2 text-success"></i> Aktifkan</a></li>
                                    <li><a class="dropdown-item" href="?update_status=suspended&id=<?php echo $row['id']; ?>"><i class="bi bi-pause-circle me-2 text-warning"></i> Suspend</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item small" href="#" onclick="viewDetail('<?php echo $row['username']; ?>', '<?php echo $row['password']; ?>')"><i class="bi bi-key me-2"></i> Intip Akun</a></li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function viewDetail(user, pass) {
        Swal.fire({
            title: 'Detail Login Hosting',
            html: `
                <div class="text-start mt-3 p-3 bg-dark rounded border border-secondary">
                    <p class="mb-2 small text-muted">Username:</p>
                    <code class="text-info">${user}</code>
                    <p class="mb-2 mt-3 small text-muted">Password:</p>
                    <code class="text-info">${pass}</code>
                </div>
            `,
            background: '#18181b',
            color: '#fff',
            confirmButtonColor: '#3b82f6'
        });
    }

    <?php if(isset($_GET['res']) && $_GET['res'] == 'updated'): ?>
        Swal.fire({
            icon: 'success',
            title: 'Status Diperbarui',
            timer: 1500,
            showConfirmButton: false,
            background: '#18181b',
            color: '#fff'
        });
    <?php endif; ?>
</script>
</body>
</html>