<?php
// Pastikan session dimulai paling atas
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Sesuaikan path ke config Anda
include '../config/database.php';

// Keamanan tambahan untuk session
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);

// Jika sudah login admin, langsung ke dashboard admin
if (isset($_SESSION['admin_id'])) {
    header("Location: dashboard.php"); 
    exit();
}

$message_type = "";
$message_text = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    // Cari di tabel admins
    $query = mysqli_query($conn, "SELECT * FROM admins WHERE username = '$username'");
    
    if (mysqli_num_rows($query) > 0) {
        $admin = mysqli_fetch_assoc($query);
        
        // Verifikasi Password Hash
        if (password_verify($password, $admin['password'])) {
            // Set session khusus admin
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['username'] = $admin['username'];
            
            $message_type = "success_login";
        } else {
            $message_type = "error";
            $message_text = "Password salah.";
        }
    } else {
        $message_type = "error";
        $message_text = "Username tidak ditemukan.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Secure Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        body { 
            background-color: #09090b; 
            font-family: 'Inter', sans-serif; 
            height: 100vh; 
            display: flex; 
            align-items: center; 
            color: #e4e4e7;
        }
        .auth-card { 
            border: 1px solid #27272a; 
            border-radius: 20px; 
            background: #18181b; 
            padding: 40px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }
        .form-control { 
            background: #27272a; 
            border: 1px solid #3f3f46; 
            color: #fff; 
            border-radius: 10px;
            padding: 12px;
        }
        .form-control:focus { 
            background: #27272a; 
            border-color: #3b82f6; 
            color: #fff; 
            box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2); 
        }
        .btn-primary { 
            background: #3b82f6; 
            border: none; 
            border-radius: 10px; 
            padding: 12px; 
            font-weight: 600;
        }
        .btn-primary:hover { background: #2563eb; }
        .input-group-text { 
            background: #27272a; 
            border: 1px solid #3f3f46; 
            color: #a1a1aa; 
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="text-center mb-4">
                <h4 class="fw-bold text-white italic"><i class="bi bi-shield-lock-fill text-primary"></i> ADMIN PANEL</h4>
            </div>
            
            <div class="card auth-card">
                <form action="" method="POST">
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-zinc-400">Username</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-person"></i></span>
                            <input type="text" name="username" class="form-control" placeholder="Admin username" required>
                        </div>
                    </div>
                    <div class="mb-4">
                        <label class="form-label small fw-bold text-zinc-400">Password</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-key"></i></span>
                            <input type="password" name="password" id="adminPass" class="form-control" placeholder="••••••••" required>
                            <button class="btn btn-outline-secondary border-secondary-subtle" type="button" onclick="togglePassword()">
                                <i class="bi bi-eye" id="eyeIcon"></i>
                            </button>
                        </div>
                    </div>
                    <button type="submit" name="login" class="btn btn-primary w-100">MASUK KE PANEL</button>
                </form>
            </div>
            <p class="text-center mt-4 text-muted small">
                &copy; 2026 Secure Access System
            </p>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function togglePassword() {
        const pass = document.getElementById('adminPass');
        const icon = document.getElementById('eyeIcon');
        if (pass.type === "password") {
            pass.type = "text";
            icon.classList.replace('bi-eye', 'bi-eye-slash');
        } else {
            pass.type = "password";
            icon.classList.replace('bi-eye-slash', 'bi-eye');
        }
    }

    // Mengikuti logika notifikasi script Anda
    <?php if($message_type == "success_login"): ?>
        Swal.fire({
            icon: 'success',
            title: 'Akses Diterima',
            text: 'Membuka panel admin...',
            timer: 1500,
            showConfirmButton: false,
            background: '#18181b',
            color: '#fff'
        }).then(() => { window.location.href = 'dashboard.php'; });
    <?php elseif($message_type == "error"): ?>
        Swal.fire({
            icon: 'error',
            title: 'Akses Ditolak',
            text: '<?php echo $message_text; ?>',
            confirmButtonColor: '#3b82f6',
            background: '#18181b',
            color: '#fff'
        });
    <?php endif; ?>
</script>
</body>
</html>