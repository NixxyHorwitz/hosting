<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../config/database.php';

// Proteksi Admin
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php"); 
    exit();
}

// Logika Hapus User
if (isset($_GET['delete_id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete_id']);
    mysqli_query($conn, "DELETE FROM users WHERE id = '$id'");
    header("Location: users.php?res=deleted");
    exit();
}

// Ambil Semua Data User
$query = mysqli_query($conn, "SELECT * FROM users ORDER BY role ASC, nama ASC");

// Hitung Statistik Sederhana
$total_users = mysqli_num_rows($query);
$total_clients = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM users WHERE role='client'"));
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pengguna - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        body { background-color: #09090b; color: #e4e4e7; font-family: 'Inter', sans-serif; }
        .sidebar { width: 260px; background: #18181b; min-height: 100vh; border-right: 1px solid #27272a; position: fixed; }
        .main-content { margin-left: 260px; padding: 40px; }
        .card-custom { background: #18181b; border: 1px solid #27272a; border-radius: 16px; overflow: hidden; }
        
        .nav-link { color: #a1a1aa; padding: 12px 20px; border-radius: 10px; margin: 5px 15px; transition: 0.3s; text-decoration: none; display: block; }
        .nav-link:hover, .nav-link.active { background: #27272a; color: #fff; }

        .stat-card { background: #18181b; border: 1px solid #27272a; border-radius: 12px; padding: 20px; }
        .table { color: #e4e4e7; border-color: #27272a; }
        .table thead { background: #27272a; color: #a1a1aa; font-size: 0.75rem; text-transform: uppercase; }
        
        .badge-admin { background: rgba(59, 130, 246, 0.1); color: #3b82f6; border: 1px solid rgba(59, 130, 246, 0.2); }
        .badge-client { background: rgba(161, 161, 170, 0.1); color: #a1a1aa; border: 1px solid rgba(161, 161, 170, 0.2); }
        
        .avatar-placeholder { width: 35px; height: 35px; background: #27272a; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; color: #3b82f6; }
        .address-text { font-size: 0.75rem; color: #71717a; max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="p-4 mb-4">
        <h5 class="fw-bold text-white"><i class="bi bi-people-fill text-primary me-2"></i> USERS MGMT</h5>
    </div>
    <nav class="nav flex-column">
        <a class="nav-link" href="dashboard.php"><i class="bi bi-speedometer2 me-2"></i> Dashboard</a>
        <a class="nav-link active" href="users.php"><i class="bi bi-people me-2"></i> Data Users</a>
        <a class="nav-link" href="orders.php"><i class="bi bi-cart me-2"></i> Orders</a>
        <a class="nav-link" href="settings.php"><i class="bi bi-gear me-2"></i> Settings</a>
        <hr class="mx-3 border-secondary">
        <a class="nav-link text-danger" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    <div class="row mb-4 align-items-center">
        <div class="col">
            <h3 class="fw-bold text-white">Manajemen Pengguna</h3>
            <p class="text-muted small">Kelola data login, lokasi, dan hak akses pengguna.</p>
        </div>
        <div class="col-auto">
            <button class="btn btn-primary rounded-pill px-4"><i class="bi bi-person-plus me-2"></i> Tambah User</button>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-3">
            <div class="stat-card">
                <div class="text-muted small">Total Pengguna</div>
                <div class="h3 fw-bold mt-1"><?php echo $total_users; ?></div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stat-card border-primary">
                <div class="text-muted small">Total Clients</div>
                <div class="h3 fw-bold mt-1 text-primary"><?php echo $total_clients; ?></div>
            </div>
        </div>
    </div>

    <div class="card card-custom">
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead>
                    <tr>
                        <th class="px-4 py-3">User</th>
                        <th>Email / WhatsApp</th>
                        <th>Lokasi</th>
                        <th>Role</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($user = mysqli_fetch_assoc($query)): ?>
                    <tr>
                        <td class="px-4">
                            <div class="d-flex align-items-center">
                                <div class="avatar-placeholder me-3">
                                    <?php echo strtoupper(substr($user['nama'], 0, 1)); ?>
                                </div>
                                <div>
                                    <div class="fw-bold text-white"><?php echo $user['nama']; ?></div>
                                    <div class="text-muted small">ID: #<?php echo $user['id']; ?></div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="text-white small"><?php echo $user['email']; ?></div>
                            <div class="text-success small"><i class="bi bi-whatsapp"></i> <?php echo $user['no_whatsapp']; ?></div>
                        </td>
                        <td>
                            <div class="text-white small"><?php echo $user['kota']; ?>, <?php echo $user['provinsi']; ?></div>
                            <div class="address-text"><?php echo $user['kabupaten']; ?>, <?php echo $user['kode_pos']; ?></div>
                        </td>
                        <td>
                            <span class="badge badge-<?php echo $user['role']; ?>">
                                <?php echo strtoupper($user['role']); ?>
                            </span>
                        </td>
                        <td class="text-center">
                            <button class="btn btn-sm btn-outline-light border-secondary me-1" onclick="viewUser('<?php echo $user['nama']; ?>', '<?php echo $user['email']; ?>', '<?php echo $user['negaravarchar'] ?? 'Indonesia'; ?>')">
                                <i class="bi bi-eye"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger border-secondary" onclick="confirmDelete(<?php echo $user['id']; ?>)">
                                <i class="bi bi-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function confirmDelete(id) {
        Swal.fire({
            title: 'Hapus Pengguna?',
            text: "Data yang dihapus tidak bisa dikembalikan!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ef4444',
            cancelButtonColor: '#27272a',
            confirmButtonText: 'Ya, Hapus!',
            background: '#18181b',
            color: '#fff'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'users.php?delete_id=' + id;
            }
        });
    }

    function viewUser(nama, email, negara) {
        Swal.fire({
            title: 'Info Detail User',
            html: `<div class="text-start small mt-2">
                    <b>Nama:</b> ${nama}<br>
                    <b>Email:</b> ${email}<br>
                    <b>Negara:</b> Indonesia
                   </div>`,
            background: '#18181b',
            color: '#fff',
            confirmButtonColor: '#3b82f6'
        });
    }

    <?php if(isset($_GET['res']) && $_GET['res'] == 'deleted'): ?>
        Swal.fire({
            icon: 'success',
            title: 'Terhapus!',
            text: 'Data pengguna telah dihapus dari sistem.',
            background: '#18181b',
            color: '#fff',
            timer: 2000,
            showConfirmButton: false
        });
    <?php endif; ?>
</script>
</body>
</html>