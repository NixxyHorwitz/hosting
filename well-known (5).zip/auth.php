<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'config/database.php';
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);

if (isset($_SESSION['user_id'])) {
    header("Location: dashboard"); 
    exit();
}

$message_type = "";
$message_text = "";

// PROSES AUTHENTIKASI
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // --- LOGIKA LOGIN ---
    if (isset($_POST['login'])) {
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = $_POST['password'];

        $query = mysqli_query($conn, "SELECT * FROM users WHERE email = '$email'");
        if (mysqli_num_rows($query) > 0) {
            $user = mysqli_fetch_assoc($query);
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_nama'] = $user['nama'];
                $message_type = "success_login";
            } else {
                $message_type = "error";
                $message_text = "Password yang Anda masukkan salah.";
            }
        } else {
            $message_type = "error";
            $message_text = "Email tidak ditemukan.";
        }
    }

    // --- LOGIKA DAFTAR ---
    if (isset($_POST['register'])) {
        $nama = mysqli_real_escape_string($conn, $_POST['nama']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $whatsapp = mysqli_real_escape_string($conn, $_POST['whatsapp']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        $cek_email = mysqli_query($conn, "SELECT id FROM users WHERE email = '$email'");
        if (mysqli_num_rows($cek_email) > 0) {
            $message_type = "error";
            $message_text = "Email sudah terdaftar, silakan login.";
        } else {
            $ins = "INSERT INTO users (nama, email, no_whatsapp, password, role) VALUES ('$nama', '$email', '$whatsapp', '$password', 'client')";
            if (mysqli_query($conn, $ins)) {
                $message_type = "success_register";
            } else {
                $message_type = "error";
                $message_text = "Gagal mendaftar, coba lagi nanti.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Akses Akun - SobatHosting</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        :root { --primary: #0d6efd; --bg: #f4f7fa; }
        body { background-color: var(--bg); font-family: 'Inter', sans-serif; height: 100vh; display: flex; align-items: center; }
        
        .auth-card { border: none; border-radius: 24px; box-shadow: 0 15px 35px rgba(0,0,0,0.08); overflow: hidden; background: #fff; }
        .auth-header { background: #fff; padding: 30px 30px 10px 30px; text-center; }
        .auth-body { padding: 30px; }
        
        .nav-pills-auth { background: #f0f2f5; padding: 5px; border-radius: 12px; margin-bottom: 25px; }
        .nav-pills-auth .nav-link { border-radius: 10px; color: #666; font-weight: 600; transition: 0.3s; }
        .nav-pills-auth .nav-link.active { background: white; color: var(--primary); box-shadow: 0 4px 10px rgba(0,0,0,0.05); }

        .form-control { border-radius: 12px; padding: 12px 15px; border: 1px solid #e0e6ed; background: #f9fbff; }
        .form-control:focus { box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1); border-color: var(--primary); }
        
        .btn-auth { border-radius: 12px; padding: 12px; font-weight: 700; letter-spacing: 0.5px; transition: 0.3s; }
        .btn-auth:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(13, 110, 253, 0.3); }

        .brand-logo { font-size: 1.5rem; font-weight: 800; color: var(--primary); text-decoration: none; }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="text-center mb-4">
                <a href="index.php" class="brand-logo">SOBATHOS.</a>
            </div>
            
            <div class="card auth-card">
                <div class="auth-header">
                    <ul class="nav nav-pills nav-fill nav-pills-auth" id="pills-tab" role="tablist">
                        <li class="nav-item">
                            <button class="nav-link active" id="tab-login" data-bs-toggle="pill" data-bs-target="#login-content">Masuk</button>
                        </li>
                        <li class="nav-item">
                            <button class="nav-link" id="tab-register" data-bs-toggle="pill" data-bs-target="#register-content">Daftar</button>
                        </li>
                    </ul>
                </div>

                <div class="auth-body">
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="login-content">
                            <form action="" method="POST">
                                <div class="mb-3">
                                    <label class="form-label small fw-bold text-muted">Email</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-envelope text-muted"></i></span>
                                        <input type="email" name="email" class="form-control border-start-0" placeholder="nama@email.com" required>
                                    </div>
                                </div>
                                <div class="mb-4">
                                    <label class="form-label small fw-bold text-muted">Password</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-transparent border-end-0"><i class="bi bi-lock text-muted"></i></span>
                                        <input type="password" name="password" id="loginPass" class="form-control border-start-0" placeholder="••••••••" required>
                                        <button class="btn btn-outline-light border border-start-0" type="button" onclick="togglePassword('loginPass')">
                                            <i class="bi bi-eye text-muted"></i>
                                        </button>
                                    </div>
                                </div>
                                <button type="submit" name="login" class="btn btn-primary w-100 btn-auth">MASUK KE AKUN</button>
                            </form>
                        </div>

                        <div class="tab-pane fade" id="register-content">
                            <form action="" method="POST">
                                <div class="mb-3">
                                    <label class="form-label small fw-bold text-muted">Nama Lengkap</label>
                                    <input type="text" name="nama" class="form-control" placeholder="John Doe" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small fw-bold text-muted">Email</label>
                                    <input type="email" name="email" class="form-control" placeholder="john@example.com" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label small fw-bold text-muted">WhatsApp</label>
                                    <input type="number" name="whatsapp" class="form-control" placeholder="62812..." required>
                                </div>
                                <div class="mb-4">
                                    <label class="form-label small fw-bold text-muted">Password</label>
                                    <input type="password" name="password" id="regPass" class="form-control" placeholder="Minimal 6 karakter" required>
                                </div>
                                <button type="submit" name="register" class="btn btn-primary w-100 btn-auth">BUAT AKUN SEKARANG</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <p class="text-center mt-4 text-muted small">Kembali ke <a href="index.php" class="text-decoration-none">Halaman Utama</a></p>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    function togglePassword(id) {
    const input = document.getElementById(id);
    const btn = event.currentTarget; // Menangkap element yang diklik
    const icon = btn.querySelector('i');
    
    if (input.type === "password") {
        input.type = "text";
        icon.classList.replace('bi-eye', 'bi-eye-slash');
    } else {
        input.type = "password";
        icon.classList.replace('bi-eye-slash', 'bi-eye');
    }
}

    // Tampilkan Notifikasi SweetAlert
    <?php if($message_type == "success_login"): ?>
        Swal.fire({
            icon: 'success',
            title: 'Berhasil Masuk!',
            text: 'Selamat datang kembali, <?php echo $_SESSION['user_nama']; ?>',
            timer: 2000,
            showConfirmButton: false
        }).then(() => { window.location.href = 'dashboard.php'; });
    <?php elseif($message_type == "success_register"): ?>
        Swal.fire({
            icon: 'success',
            title: 'Pendaftaran Berhasil!',
            text: 'Silakan login menggunakan email dan password Anda.',
            confirmButtonColor: '#0d6efd'
        });
    <?php elseif($message_type == "error"): ?>
        Swal.fire({
            icon: 'error',
            title: 'Opps!',
            text: '<?php echo $message_text; ?>',
            confirmButtonColor: '#0d6efd'
        });
    <?php endif; ?>
</script>
</body>
</html>