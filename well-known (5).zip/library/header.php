<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Pastikan koneksi $conn sudah ada sebelum file ini di-include
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $query = mysqli_query($conn, "SELECT nama FROM users WHERE id = '$user_id'");
    $data = mysqli_fetch_assoc($query);
    $user_nama = $data['nama'] ?? "User";
} else {
    $user_nama = "Tamu"; 
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SobatHosting - Control Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root { 
            --primary: #2563eb; 
            --primary-light: #eff6ff;
            --bg: #f8fafc; 
            --sidebar-width: 280px;
        }
        
        body { 
            background-color: var(--bg); 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            color: #1e293b;
            overflow-x: hidden;
        }

        /* Sidebar Modern Style */
        .sidebar { 
            width: var(--sidebar-width); 
            height: 100vh; 
            background: white; 
            position: fixed; 
            left: 0; 
            top: 0; 
            z-index: 1050; 
            border-right: 1px solid rgba(0,0,0,0.05); 
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .sidebar-brand {
            padding: 2rem 1.5rem;
            font-weight: 800;
            font-size: 1.5rem;
            letter-spacing: -1px;
            color: var(--primary);
        }

        .nav-link { 
            color: #64748b; 
            padding: 12px 1.5rem; 
            margin: 4px 12px; 
            border-radius: 12px; 
            display: flex; 
            align-items: center; 
            text-decoration: none; 
            font-weight: 500;
            transition: all 0.2s; 
        }

        .nav-link i { font-size: 1.25rem; margin-right: 12px; transition: 0.2s; }

        .nav-link:hover, .nav-link.active { 
            background: var(--primary-light); 
            color: var(--primary); 
        }

        .nav-link.active i { color: var(--primary); }

        /* Sub-menu styling */
        .collapse-inner {
            margin-left: 2.5rem;
            border-left: 2px solid #f1f5f9;
            padding-left: 0.5rem;
        }

        .nav-link.sub-item {
            font-size: 0.9rem;
            padding: 8px 1rem;
        }

        /* Main Content Area */
        .main-content { 
            margin-left: var(--sidebar-width); 
            padding: 2rem; 
            transition: all 0.3s; 
            min-height: 100vh;
        }

        /* Mobile View Adjustments */
        .sidebar-overlay {
            position: fixed;
            top: 0; left: 0; width: 100vw; height: 100vh;
            background: rgba(15, 23, 42, 0.5);
            backdrop-filter: blur(4px);
            z-index: 1040;
            display: none;
        }

        @media (max-width: 991.98px) {
            .sidebar { left: calc(-1 * var(--sidebar-width)); }
            .sidebar.active { left: 0; box-shadow: 20px 0 50px rgba(0,0,0,0.1); }
            .main-content { margin-left: 0; padding: 1.25rem; }
            .sidebar-overlay.active { display: block; }
            .top-bar-mobile { display: flex !important; }
        }

        .top-bar-mobile { 
            display: none; 
            background: rgba(255, 255, 255, 0.8); 
            backdrop-filter: blur(10px);
            padding: 0.75rem 1.25rem; 
            justify-content: space-between; 
            align-items: center; 
            border-radius: 15px;
            border: 1px solid rgba(255,255,255,0.3);
            margin-bottom: 1.5rem;
            position: sticky;
            top: 10px;
            z-index: 1000;
        }

        /* Profile Dropdown */
        .user-dropdown-btn {
            background: white;
            border: 1px solid #e2e8f0;
            padding: 0.5rem 1rem;
            border-radius: 100px;
            transition: all 0.2s;
        }
        .user-dropdown-btn:hover { background: #f8fafc; border-color: var(--primary); }

        /* Rotate chevron on collapse */
        [aria-expanded="true"] .bi-chevron-down {
            transform: rotate(180deg);
        }
        .bi-chevron-down { transition: transform 0.3s; }
    </style>
</head>
<body>

<div class="sidebar-overlay" id="overlay" onclick="toggleMenu()"></div>

<nav class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        SOBATHOS<span class="text-dark">.</span>
    </div>
    
    <div class="nav flex-column mt-2">
        <a href="<?= base_url('/') ?>" class="nav-link active">
            <i class="bi bi-grid-1x2-fill"></i> Dashboard
        </a>

        <a class="nav-link" data-bs-toggle="collapse" href="#menuHosting" role="button">
            <i class="bi bi-hdd-stack"></i> Hosting 
            <i class="bi bi-chevron-down ms-auto small"></i>
        </a>
        <div class="collapse" id="menuHosting">
            <div class="collapse-inner">
                <a href="<?= base_url('hosting/') ?>" class="nav-link sub-item">Beli Hosting</a>
                <a href="<?= base_url('hosting/layanan') ?>" class="nav-link sub-item">Layanan Saya</a>
            </div>
        </div>

     
        </div>

        <div class="px-4 mt-4 mb-2 small text-uppercase fw-bold text-muted" style="font-size: 0.7rem; letter-spacing: 1px;">Transaksi</div>
        
        <a href="<?= base_url('order') ?>" class="nav-link">
            <i class="bi bi-receipt"></i> Riwayat Pesanan
        </a>
        
        <a href="<?= base_url('billing') ?>" class="nav-link">
            <i class="bi bi-credit-card"></i> Pembayaran
        </a>

        <div class="mt-auto mb-4 p-3">
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="<?= base_url('logout') ?>" class="nav-link text-danger bg-danger-subtle">
                    <i class="bi bi-box-arrow-left"></i> Keluar
                </a>
            <?php else: ?>
                <a href="<?= base_url('auth') ?>" class="nav-link text-primary bg-primary-subtle">
                    <i class="bi bi-box-arrow-in-right"></i> Login Pelanggan
                </a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<div class="main-content">
    <div class="top-bar-mobile shadow-sm">
        <button class="btn btn-light rounded-circle p-2" onclick="toggleMenu()">
            <i class="bi bi-list fs-4"></i>
        </button>
        <span class="fw-bold">SobatHosting</span>
        <div class="avatar-small bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 35px; height: 35px;">
            <?= substr($user_nama, 0, 1) ?>
        </div>
    </div>

    <div class="d-flex justify-content-between align-items-center mb-5 d-none d-md-flex">
        <div>
            <h2 class="fw-800 m-0 text-dark" style="letter-spacing: -1px;">Halo, <?= explode(' ', trim($user_nama))[0]; ?>! 👋</h2>
            <p class="text-secondary">Kelola semua layanan cloud Anda dalam satu dashboard.</p>
        </div>
        
        <div class="dropdown">
            <button class="user-dropdown-btn dropdown-toggle shadow-sm" data-bs-toggle="dropdown">
                <i class="bi bi-person-circle text-primary me-2"></i>
                <span class="fw-semibold"><?= $user_nama; ?></span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end border-0 shadow-lg mt-3 p-2 rounded-4">
                <li><a class="dropdown-item rounded-3 py-2" href="profile.php"><i class="bi bi-person me-2"></i> Profil</a></li>
                <li><a class="dropdown-item rounded-3 py-2" href="settings.php"><i class="bi bi-gear me-2"></i> Pengaturan</a></li>
                <li><hr class="dropdown-divider opacity-50"></li>
                <li><a class="dropdown-item rounded-3 py-2 text-danger" href="logout.php"><i class="bi bi-box-arrow-left me-2"></i> Keluar</a></li>
            </ul>
        </div>
    </div>

    <script>
        function toggleMenu() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('overlay');
            sidebar.classList.toggle('active');
            overlay.classList.toggle('active');
        }
    </script>