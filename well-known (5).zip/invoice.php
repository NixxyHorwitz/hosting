<?php
include 'config/database.php';
session_start();

$order_id = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : '';

if (empty($order_id)) {
    die("Akses Ditolak: ID Invoice tidak disertakan.");
}

// Ambil data order hosting (Logic domain dihapus sesuai permintaan)
$sql = "SELECT o.*, hp.nama_paket, hp.harga_per_bulan, u.nama, u.email 
        FROM orders o 
        LEFT JOIN hosting_plans hp ON o.hosting_plan_id = hp.id 
        LEFT JOIN users u ON o.user_id = u.id 
        WHERE o.id = '$order_id'";

$query = mysqli_query($conn, $sql);
$inv = mysqli_fetch_assoc($query);

if (!$inv) {
    die("Invoice Hosting #$order_id tidak ditemukan.");
}

$item_name     = "Paket Hosting " . $inv['nama_paket'];
$item_detail   = $inv['domain'];
$harga_bulanan = $inv['harga_per_bulan'];
$durasi        = $inv['durasi'];
$total_harga   = $inv['total_harga'];
$status        = $inv['status_pembayaran']; // Menggunakan status_pembayaran
$tanggal       = $inv['created_at'];
$qr_code_url   = $inv['qr_code_url']; // Ambil URL QRIS dari database

$methods = mysqli_query($conn, "SELECT * FROM payment_methods WHERE status = 'on'");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice #<?php echo $order_id; ?> - SobatHosting</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary: #2563eb;
            --slate-900: #0f172a;
        }
        body { background-color: #f4f7fa; font-family: 'Inter', sans-serif; color: var(--slate-900); }
        .invoice-wrapper { max-width: 850px; margin: 40px auto; padding: 0 20px; }
        .card-invoice { border: none; border-radius: 24px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); background: white; overflow: hidden; }
        .inv-header { background: var(--slate-900); color: white; padding: 40px 50px; }
        .status-badge { padding: 6px 14px; border-radius: 100px; font-weight: 700; font-size: 0.75rem; text-transform: uppercase; }
        .bg-pending { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; }
        .bg-success { background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; }
        
        /* QRIS Styling */
        .qris-container {
            background: #fff;
            border: 2px dashed #e2e8f0;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            text-align: center;
        }
        .qris-image {
            max-width: 250px;
            height: auto;
            margin: 15px 0;
            border: 1px solid #eee;
            padding: 10px;
            border-radius: 10px;
        }
        
        .payment-box { border: 1.5px solid #e2e8f0; border-radius: 16px; padding: 15px 20px; cursor: pointer; transition: 0.3s; }
        .payment-box:hover, .payment-box.active { border-color: var(--primary); background: #f0f7ff; }
        .total-section { background: #f8fafc; border-radius: 20px; padding: 25px; }

        @media print { .no-print { display: none !important; } .card-invoice { box-shadow: none; border: 1px solid #eee; } }
    </style>
</head>
<body>

<div class="invoice-wrapper">
    <div class="mb-4 d-flex justify-content-between align-items-center no-print">
        <a href="index.php" class="text-decoration-none text-dark fw-bold small">
            <i class="bi bi-chevron-left"></i> Kembali
        </a>
        <button onclick="window.print()" class="btn btn-light shadow-sm btn-sm fw-bold px-4 border rounded-pill">
            <i class="bi bi-printer me-2"></i> Cetak Invoice
        </button>
    </div>

    <div class="card card-invoice">
        <div class="inv-header d-flex justify-content-between align-items-center">
            <div>
                <div class="h3 fw-800 mb-0">SOBATHOS<span class="text-primary">.</span></div>
                <p class="small m-0 opacity-50">Cloud Infrastructure Solution</p>
            </div>
            <div class="text-end">
                <h1 class="h5 fw-bold m-0 text-uppercase">Invoice Hosting</h1>
                <span class="opacity-50 small">#INV/<?php echo $order_id; ?></span>
            </div>
        </div>
        
        <div class="card-body p-4 p-md-5">
            <div class="row g-4 mb-5">
                <div class="col-6">
                    <label class="text-uppercase text-muted small fw-bold mb-2 d-block">Pelanggan</label>
                    <h6 class="fw-bold m-0"><?php echo $inv['nama']; ?></h6>
                    <p class="text-muted small m-0"><?php echo $inv['email']; ?></p>
                </div>
                <div class="col-6 text-end">
                    <label class="text-uppercase text-muted small fw-bold mb-2 d-block">Status Pembayaran</label>
                    <span class="status-badge bg-<?php echo $status; ?>">
                        <i class="bi bi-dot"></i> <?php echo strtoupper($status); ?>
                    </span>
                </div>
            </div>

            <div class="table-responsive mb-4">
                <table class="table align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Deskripsi Layanan</th>
                            <th class="text-end">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <div class="fw-bold text-dark"><?php echo $item_name; ?></div>
                                <div class="text-primary small"><i class="bi bi-globe me-1"></i> <?php echo $item_detail; ?></div>
                                <div class="badge bg-light text-dark border mt-2 fw-normal">Durasi: <?php echo $durasi; ?> Bulan</div>
                            </td>
                            <td class="text-end">
                                <div class="fw-bold">Rp <?php echo number_format($total_harga, 0, ',', '.'); ?></div>
                                <div class="small text-muted"><?php echo $durasi; ?> x Rp <?php echo number_format($harga_bulanan, 0, ',', '.'); ?></div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="row justify-content-end mb-5">
                <div class="col-md-5">
                    <div class="total-section text-end">
                        <div class="fw-bold text-muted small text-uppercase">Total Bayar</div>
                        <div class="h3 fw-800 text-primary m-0">Rp <?php echo number_format($total_harga, 0, ',', '.'); ?></div>
                    </div>
                </div>
            </div>

            <hr class="my-5 opacity-5">

            <?php if($status == 'pending'): ?>
            <div class="no-print">
                
                <?php if(!empty($qr_code_url)): ?>
                <div class="qris-container">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Logo_QRIS.svg/1200px-Logo_QRIS.svg.png" width="100" alt="Logo QRIS" class="mb-3">
                    <h5 class="fw-bold">Scan QRIS Untuk Bayar</h5>
                    <p class="small text-muted">Silakan scan kode QR di bawah ini menggunakan aplikasi Bank atau E-Wallet (Gopay, OVO, Dana, LinkAja)</p>
                    <img src="https://asteelass.icu/<?php echo $qr_code_url; ?>" class="qris-image shadow-sm" alt="QRIS Pembayaran">
                    <div class="mt-2 fw-bold text-primary small">Total Tagihan: Rp <?php echo number_format($total_harga, 0, ',', '.'); ?></div>
                </div>
                <?php endif; ?>

                <div class="text-center mb-4">
                    <h6 class="fw-bold">Metode Pembayaran Lainnya</h6>
                </div>
                
                <div class="row g-3 mb-4">
                    <?php while($m = mysqli_fetch_assoc($methods)): ?>
                    <div class="col-md-6">
                        <div class="payment-box d-flex align-items-center justify-content-between" 
                             onclick="pilihBayar(this, '<?php echo $m['nama_metode']; ?>', '<?php echo $m['keterangan']; ?>')">
                            <div class="fw-bold small"><?php echo $m['nama_metode']; ?></div>
                            <i class="bi bi-chevron-right small text-muted"></i>
                        </div>
                    </div>
                    <?php endwhile; ?>
                </div>

                <div id="box-instruksi" class="p-4 rounded-4 d-none text-center bg-light">
                    <h5 class="fw-bold" id="title-metode"></h5>
                    <div id="detail-metode" class="h4 text-primary fw-bold my-2"></div>
                    <p class="text-muted small mb-3">Silakan transfer sesuai nominal di atas.</p>
                    <a href="https://wa.me/62812345678?text=Halo%20Admin,%20Konfirmasi%20Bayar%20INV%20<?php echo $order_id; ?>" class="btn btn-success btn-sm px-4 rounded-pill">
                        <i class="bi bi-whatsapp me-2"></i> Konfirmasi WhatsApp
                    </a>
                </div>
            </div>
            <?php else: ?>
                <div class="py-5 text-center bg-success bg-opacity-10 rounded-4">
                    <i class="bi bi-patch-check-fill text-success display-4"></i>
                    <h4 class="fw-bold text-success mt-3">Pembayaran Berhasil</h4>
                    <p class="text-muted">Terima kasih, layanan Anda sudah aktif.</p>
                </div>
            <?php endif; ?>

            <div class="text-center mt-5 opacity-50 small">
                &copy; 2026 SobatHosting Tech &bull; Indonesia
            </div>
        </div>
    </div>
</div>

<script>
function pilihBayar(el, nama, detail) {
    document.querySelectorAll('.payment-box').forEach(box => box.classList.remove('active'));
    el.classList.add('active');
    const box = document.getElementById('box-instruksi');
    box.classList.remove('d-none');
    document.getElementById('title-metode').innerText = nama;
    document.getElementById('detail-metode').innerText = detail;
    box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}
</script>

</body>
</html>