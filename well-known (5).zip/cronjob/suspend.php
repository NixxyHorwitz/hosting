<?php
// Menggunakan __DIR__ agar path tetap aman saat dipanggil oleh sistem cron
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../core/WHMClient.php';

$whm = new WHMClient();
$now = date('Y-m-d H:i:s');

echo "--- Memulai Proses Cron Suspend: $now ---\n";

/**
 * LOGIKA:
 * 1. Cari akun yang 'active' tapi 'expiry_date' sudah lewat.
 * 2. Suspend di WHM.
 * 3. Update status akun jadi 'suspended'.
 * 4. Update status_pembayaran jadi 'pending' (agar mereka harus bayar lagi untuk perpanjang).
 */

$query_expired = mysqli_query($conn, "SELECT id, username FROM orders WHERE status = 'active' AND expiry_date <= '$now'");

if (mysqli_num_rows($query_expired) > 0) {
    while ($row = mysqli_fetch_assoc($query_expired)) {
        $id = $row['id'];
        $user = $row['username'];

        try {
            // 1. Perintah Suspend ke WHM
            $whm->suspendAccount($user, "Masa aktif habis. Silahkan lakukan pembayaran perpanjangan.");

            // 2. Update Database (Status Akun & Status Pembayaran)
            $update = mysqli_query($conn, "UPDATE orders SET 
                status = 'suspended', 
                status_pembayaran = 'pending' 
                WHERE id = '$id'");
            
            if ($update) {
                echo "[SUCCESS] Akun $user telah di-suspend dan status_pembayaran di-reset ke pending.\n";
            }
        } catch (Exception $e) {
            echo "[ERROR] Gagal memproses $user: " . $e->getMessage() . "\n";
        }
    }
} else {
    echo "Tidak ada akun yang expired saat ini.\n";
}

echo "--- Proses Selesai ---\n";